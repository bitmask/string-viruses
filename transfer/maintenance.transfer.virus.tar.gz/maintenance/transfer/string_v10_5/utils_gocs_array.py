#!/usr/bin/env python
# utils_gocs_array.py

import os
import sys
import subprocess
import time
import gc
import math
import gc
from operator import itemgetter

#rrutils = ""
#rropen  = ""

#gc.disable

# TS the question is: when we have score 0.999 we don't add anything but it's suport our link
# The same with clades... we don't transfer from lower scoreing things, but still they support our link

# Initiate global variables
# The values are passed from parent script

px                                     = ""
clades_file                            = ""
protein_links_file                     = ""
horthogroups_mapping_dir = ""
vorthogroups_mapping_dir = ""
tax_tree_file                          = ""
orthogroup_file_name                   = ""
connectivity_file_name                 = ""
connectivity_dir                       = ""
homology_file                          = ""
host_species_in_levels_file            = ""
virus_species_in_levels_file           = ""
homology_substract_score_pos           = ""
prot_prot_links_dir_divided_by_taxid   = ""
score_name                             = ""
protein_links_file_name                = ""
host_species_similarity_file           = ""
virus_species_similarity_file          = ""
score_range                            = 1
epsilon_shift                          = 0.0
epsilon_steep                          = 0.0

beta                                   = 0.0
delta                                  = 0.0
gamma                                  = 0.0

action_channels_to_str                 = {}

is_test = False


def load_everything(level_og, hogs_to_compute, vogs_to_compute):

    print >> sys.stderr, level_og
    
    # Reset the dictionaries

    #global prots_ogs
    #global ogs_prots
    #global ogs_taxid
    #global prots_taxid
    global host_prots_ogs
    global host_ogs_prots
    global host_ogs_taxid
    global host_prots_taxid
    global virus_prots_ogs
    global virus_ogs_prots
    global virus_ogs_taxid
    global virus_prots_taxid
    global prot_prot_scores 
    global tax_tree
    #global all_protein_taxids
    global all_og_taxids
    #global clades_sps, sps_clade
    #global count_ogs_proteins
    #global prot_connectivity
    global species_similarity
    global sps_in_level
    global vsps_in_level
    global all_species
    
# TODO separate virus/host
    host_prots_ogs, host_ogs_prots, host_ogs_taxid, host_prots_taxid = {}, {}, {}, {}
    virus_prots_ogs, virus_ogs_prots, virus_ogs_taxid, virus_prots_taxid = {}, {}, {}, {}
    #prots_ogs, ogs_prots, ogs_taxid, prots_taxid          = {}, {}, {}, {}
    prot_prot_scores = {}
    #, clades_sps, sps_clade               = {}, {}
    #count_ogs_proteins, prot_connectivity, all_protein_taxids = {}, {}, {}
    tax_tree       = {}
    all_og_taxids = {}
    species_similarity = {} # one data structure for both virus and host
    vsps_in_level, sps_in_level, all_species = {}, {}, set()
    
    # Reset local dictionaries
    
    relevant_proteins = {}
    homology_scores   = {} 
    
    gc.collect
    
    # Load taxonomy tree and all taxids
    
    for line in open(tax_tree_file):
        taxid, parent_taxid = line.rstrip().split("\t")
        
        tax_tree[int(taxid)] = int(parent_taxid)
        all_og_taxids[int(parent_taxid)] = 1
    
    # Load species similarity matrix, separate files for hosts and viruses, but store in one hash
    
    for line in open(host_species_similarity_file):
        if not line.startswith("#"):
            l = line.strip().split("\t")
            taxid1, taxid2, sim = int(l[0]), int(l[1]), float(l[2])
            if taxid1 not in species_similarity: species_similarity[taxid1] = {}
            species_similarity[taxid1][taxid2] = sim
    
    for line in open(virus_species_similarity_file):
        l = line.strip().split("\t")
        taxid1, taxid2, sim = int(l[0]), int(l[1]), float(l[2])
        if taxid1 not in species_similarity: species_similarity[taxid1] = {}
        species_similarity[taxid1][taxid2] = sim

    # Load species from level
    
    #######################################################################
    # Load species in levels file
    #######################################################################
    
    # separate files for virus and host, and store in separate hashes except for all_species

    for line in open(host_species_in_levels_file):
        l = line.strip().split("\t")
        level = int(l[0])
        sps_in_level[level] = {}
        sps_in_level[level] = [int(sp) for sp in l[1].split()]
        for sp in [int(sp) for sp in l[1].split()]:
            all_species.add(sp)
 
    for line in open(virus_species_in_levels_file):
        l = line.strip().split("\t")
        level = int(l[0])
        vsps_in_level[level] = {}
        vsps_in_level[level] = [int(sp) for sp in l[1].split()]
        for sp in [int(sp) for sp in l[1].split()]:
            all_species.add(sp)

    count = 0

    action_channel_count    = 0
    action_channels_to_int  = {}


    for line in open(protein_links_file):  # all virus-host links are in one file which is not symmetric
        
        l = line.rstrip().split("\t")
        
        sp, prot1, prot2, channel, action, score = l
        
        action_channel = channel + " " + action

        if prot1 == "": continue
        if prot2 == "": continue
        
        prot1 = int(prot1)
        prot2 = int(prot2)
        score = float(score)
        
        if score > px:

            if action_channel in action_channels_to_int:
                action_channel_int = action_channels_to_int[action_channel]
            else:
                action_channels_to_int[action_channel] = action_channel_count
                action_channels_to_str[action_channel_count] = action_channel
                action_channel_int = action_channel_count
                action_channel_count += 1

            if prot1 not in prot_prot_scores:
                prot_prot_scores[prot1] = {}

            if prot2 not in prot_prot_scores[prot1]:
                prot_prot_scores[prot1][prot2] = {action_channel_int:score}
            else:
                prot_prot_scores[prot1][prot2][action_channel_int] = score
                
            # ensure it is symmetric
            if prot2 not in prot_prot_scores:
                prot_prot_scores[prot2] = {}
                            
            if prot1 not in prot_prot_scores[prot2]:
                prot_prot_scores[prot2][prot1] = {action_channel_int:score}
            else:
                prot_prot_scores[prot2][prot1][action_channel_int] = score

    print >> sys.stderr, "Links loaded..." + str(len(prot_prot_scores.keys()))
    
    # Load orthologous groups

    # load virus_ogs_prots with all data, then populate virus_prots_ogs with interaction specific data because only this var is used later

    for vlevel in vsps_in_level.keys():
        v_og_file = os.path.join(vorthogroups_mapping_dir, str(vlevel) + ".og_protid.tsv")
        for line in open(v_og_file):
            vog, vprot_taxid, vprot = line.strip().split()
            if vog not in virus_ogs_prots: virus_ogs_prots[vog] = {}
            virus_ogs_prots[vog][int(vprot)] = 1

            if int(vprot) in virus_prots_taxid: virus_prots_taxid = {}
            virus_prots_taxid[int(vprot)] = vprot_taxid

    divided_og_file =  os.path.join(horthogroups_mapping_dir, str(level_og) + ".og_protid.tsv")
    
    for line in open(divided_og_file):
        l = line.strip().split()
        
        og, prot_taxid, prot = l[0], int(l[1]), int(l[2])

        
        if prot in prot_prot_scores:
        
            host_ogs_taxid[og]     = level_og
            host_prots_taxid[prot] = prot_taxid
            
            if not is_test or (is_test and og in hogs_to_compute): # BENCHMARK!!!!
                relevant_proteins[prot] = 1
            
                if prot not in host_prots_ogs: host_prots_ogs[prot] = {}
                host_prots_ogs[prot][og] = 1
                
                if og not in host_ogs_prots: host_ogs_prots[og] = {}
                host_ogs_prots[og][prot] = 1
                #if og not in count_ogs_proteins: count_ogs_proteins[og] = 0
                
                #count_ogs_proteins[og] += 1

            # go through all levels and populate virus_prots_ogs
            for vprot in prot_prot_scores[prot]:
                for vog in virus_ogs_prots.keys():
                    if vprot in virus_ogs_prots[vog]:
                        if vprot not in virus_prots_ogs: virus_prots_ogs[vprot]  = {}
                        virus_prots_ogs[vprot][vog] = 1
                

    
    print >> sys.stderr, "Orthogroups loaded..."

    
def is_species(taxid):
    if taxid in all_species:
        return True
    return False

def combine_scores(og, fro): # for og to compute going up tree of host levels
    #fro is filehandle for report output

    ## These hash contain results for this og
    combined_scores = {}
    
    if og not in host_ogs_prots: return combined_scores

    level_taxid = host_ogs_taxid[og]
    
    target_taxids = set()
    
    # Results for current level
    target_taxids.add(level_taxid)
    
    # Results for direct child 
    # for taxid in tax_tree:
    #     if is_direct_child(taxid, level_taxid):
    #         target_taxids.add(taxid)

    # Results for species level
    # for taxid in sps_in_level[level_taxid]:
    #     target_taxids.add(taxid)
    # 
    # for taxid in target_taxids:
    #     if taxid not in combined_scores: combined_scores[taxid] = {}

    ## For every protein in host og
    for prot in host_ogs_prots[og]:
        
        if prot not in prot_prot_scores: continue
        
        ## Now we find all the taxonomy levels that this particular protein belong to
        ## We will combine scores separetly for them, as we want to know all the sub-levels scores for this og
        ## This is needed for transfer down not up. 
        
        target_taxids = {host_prots_taxid[prot]:1, host_ogs_taxid[og]:1} # for protein level and full of level
    
        for taxid in target_taxids:
            if taxid not in combined_scores: combined_scores[taxid] = {}

        #target_taxids = {ogs_taxid[og]:1}                      # for full og level
        
        #target_taxids = {ogs_taxid[og]:1} # compute for full og
        
        # We need to compute all the child levels including protein
        

        #for taxid in all_og_taxids:
        #    if taxid == 1: continue
        #    if is_child(taxid, ogs_taxid[og]) and is_child(prots_taxid[prot], taxid):
        #        target_taxids[taxid] = 1 
        #
        
        # TO DO: SPEED THIS UP BY CREATING DICTIONARY
        
        f1 = compute_fraction(prot, og, True) # fraction that this protein represents of it's species in the og
        
        # TODO for all virus levels
        for vlevel in vsps_in_level.keys():
            for partner_prot in prot_prot_scores[prot]: # for it's every interaction
                if partner_prot not in virus_prots_ogs: continue #?????
                
                for partner_og in virus_prots_ogs[partner_prot]:
                    if og == partner_og: continue
                    # TO DO: SPEED THIS UP BY CREATING DICTIONARY
                    f2 = compute_fraction(partner_prot, partner_og, False)
                    
                    for target_taxid in target_taxids:
                        if vlevel not in combined_scores[target_taxid]: combined_scores[target_taxid][vlevel] = {}
                        if partner_og not in combined_scores[target_taxid][vlevel]:
                            combined_scores[target_taxid][vlevel][partner_og] = {} # actions                
                                        
                    for action_mode, score in prot_prot_scores[prot][partner_prot].iteritems():
                        report_printed = False
                        for target_taxid in target_taxids:
        
                            if is_species(target_taxid):
                                fraction_modifier = 1  
                            else:
                                fraction_modifier = (f1*f2)**beta
                            
                            score = fraction_modifier*score
                            if score <= px: continue
                                      
                            #TODO add viruslevel to combined_scores 2nd pos
                            if action_mode not in combined_scores[target_taxid][vlevel][partner_og]:
                                combined_scores[target_taxid][vlevel][partner_og][action_mode] = {}
                                                  
                                # Here we chose the highest of the scores for the species.
                                # We do that becasue we assume that scores from the same species are not idependent.
                                    
                            prot_taxid = host_prots_taxid[prot]
                            
                            #if target_taxid == prot_taxid or target_taxid == ogs_taxid[og]: # THIS COULD BE FASTER
                            #if target_taxid == prot_taxid or is_child(prot_taxid, target_taxid): # THIS COULD BE FASTER
                            # DO THIS UNCONDITIONALLY for cross species links
                            if not report_printed:
                                print >> fro, "\t".join([og, str(vlevel), str(partner_og), str(prot_taxid), str(prot), str(partner_prot), action_channels_to_str[action_mode]])
                                report_printed = True
                            
                            if prot_taxid not in combined_scores[target_taxid][vlevel][partner_og][action_mode]:
                                combined_scores[target_taxid][vlevel][partner_og][action_mode][prot_taxid] = score
                            elif score > combined_scores[target_taxid][vlevel][partner_og][action_mode][prot_taxid]:
                                combined_scores[target_taxid][vlevel][partner_og][action_mode][prot_taxid] = score
                                    

    for target_taxid in combined_scores:
        for vlevel in combined_scores[target_taxid]:
            for partner_og in combined_scores[target_taxid][vlevel]:
                for action_mode in combined_scores[target_taxid][vlevel][partner_og]:
                    
                            
                    combined_score = px
        
                    taxids_previously_combined = {}
                    
                    score_taxid_list = sorted(combined_scores[target_taxid][vlevel][partner_og][action_mode].iteritems(), key=lambda x:(x[1],x[0]), reverse=True)
                    
                    for taxid, score in score_taxid_list:
                        
                        max_sim = 0
                        
                        for taxid_previously_combined in taxids_previously_combined:
    
                            if taxid_previously_combined not in species_similarity[taxid]:
                                continue
                            else:
                                sim = species_similarity[taxid][taxid_previously_combined]
                                if sim > max_sim: max_sim = sim
                        
                        taxids_previously_combined[taxid] = 1
    
                        if max_sim:
                            score = combined_scores[target_taxid][vlevel][partner_og][action_mode][taxid] * (1 - (1 / (1 + math.exp(gamma * (delta - max_sim) ) ) ) )
    
                        if score > px:
                            combined_score = ((1-combined_score)/(1-px))*((1-score)/(1-px))
                            combined_score = 1 - ((1-px)*combined_score)
        
                        if combined_score > 0.999:
                            combined_score = 0.999
                            break
        
                    combined_scores[target_taxid][vlevel][partner_og][action_mode] = combined_score
    
        
    return combined_scores

        
def is_child(child_taxid, parent_taxid):
    taxid = tax_tree[child_taxid]
    
    if taxid == parent_taxid:
        return True
    elif taxid == 1:
        return False
    else:
        return is_child(taxid, parent_taxid)

def is_direct_child(child_taxid, parent_taxid):
    if tax_tree[child_taxid] == parent_taxid:
        return True
    else:
        return False
    

def go_up(taxid):
    taxid = tax_tree[taxid]
    
    if taxid in all_og_taxids:
        return taxid
    else:
        return go_up(taxid)


def compute_fraction(prot, og, host):
    if host:
        prots_taxid = host_prots_taxid
        prot_taxid = prots_taxid[prot]
        ogs_prots = host_ogs_prots
    else:
        prots_taxid = virus_prots_taxid
        if prot not in prots_taxid: return 1
        prot_taxid = prots_taxid[prot]
        ogs_prots = virus_ogs_prots

    
    count_siblings = 0
    
    for sibling_prot in ogs_prots[og]:
        if prots_taxid[sibling_prot] == prot_taxid:
            count_siblings += 1
    
    return float(1)/count_siblings
    

def d(text):
    str(text)
    raw_input(text)

