from subprocess import Popen
from subprocess import PIPE
import os
import sys
#from rrutils import rropen
max_processes = 20

from multiprocessing import Process
import subprocess

from time import sleep


run_dir     = "/mnt/mnemo2/damian/string/maintenance/transfer/string/string_v10_5/"
derived_dir = "/mnt/mnemo4/damian/STRING_v10_5/STRING_derived_v10_5/transfer/transfer_output/"
kegg_dir    = "/mnt/mnemo4/damian/STRING_v10_5/STRING_derived_v10_5/transfer/benchmark_levels/"




def run_process(input_file, output_file, species):
    
    output_dir = output_file.rsplit("/", 1)[0]
    kegg_file = kegg_dir+species+".benchmark_kegg.tsv"
    
    
    if os.path.exists(output_file):
        print "exists...", output_file
        return

    
    
    initL = """perl {3}/calibrate_file.pl {0} {1} {2}""".format(input_file, output_file, kegg_file, run_dir)
    
    subprocess.Popen(initL, shell=True).wait()

channels = [
    #"textmining",
    "equiv",
    #"database",
    #"array",
    #"actions",
    #"experimental",
]

init_params = []

for channel in channels:

    input_dir   = derived_dir + channel + "/"
    output_dir  = derived_dir + channel + "_calibrated/"

    if not os.path.exists(output_dir):
        os.system("mkdir " + output_dir)
    
    for file_ in os.listdir(derived_dir+channel):

        if channel in file_:
            species = file_.split(".")[0]
            
            input_file  = input_dir  + file_
            output_file = output_dir + file_
            
            init_params.append( (input_file, output_file, species ) )
            
            
processes = {}

for process_num in range(max_processes):
            
    if len(init_params):        
        init_param = init_params.pop(0)
        
        print >> sys.stderr, "Initiating process (initial) %d" % process_num
        processes[process_num] = Process(target=run_process, args=init_param)
        processes[process_num].start()
        
        sleep(0.1)


if len(init_params):
    while True:
        
        for process_num, process in processes.iteritems():
            if not process.is_alive():
                print >> sys.stderr, "Initiating process in spot %d" % process_num
                init_param = init_params.pop(0)
                processes[process_num] = Process(target=run_process, args=(init_param))
                processes[process_num].start()
                sleep(0.1)
                
            if len(init_params) == 0: break
        if len(init_params) == 0: break

#
# Wait till processes finish
#

print >> sys.stderr, "Waiting for processes to finish..."

while True:
    still_running = False
    for process_num, process in processes.iteritems():        
        if process.is_alive():
            still_running = True
    
    if not still_running:
        break
    
    sleep(1)

print >> sys.stderr, "Finished executing...."

sys.exit()










