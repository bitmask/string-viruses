#!/usr/bin/env python


transfer_dir = "/mnt/mnemo4/damian/STRING_v10_5/STRING_derived_v10_5/transfer/"

dbdump          = transfer_dir+"/network.actions.v10_5.dump"
shorhands_file = transfer_dir+"/protein.shorthands.txt"
outfile        = transfer_dir+"/full_actions_score.tsv"

proitd_sp = {}
for line in open(shorhands_file):
    l = line.strip().split("\t")
    proitd_sp[l[1]] = l[0].split(".")[0]


fh_out = open(outfile, "w")

c = 0
for line in open(dbdump):

    l = line.strip().split("\t")

    if len(l) < 5:  continue

    pid1, pid2, mode, action, is_directional, a_is_acting, score = l
    
    sp = proitd_sp[pid1]
    score = str(round(float(score)/1000,3))  
    print >> fh_out, "\t".join([sp, pid1, pid2, mode, "_".join([action, is_directional, a_is_acting]), score])


fh_out.close()    

