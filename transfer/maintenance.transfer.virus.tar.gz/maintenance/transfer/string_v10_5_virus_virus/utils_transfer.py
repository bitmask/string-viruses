#!/usr/bin/env python

import os
import sys
import time
from collections import defaultdict
from subprocess import Popen
from subprocess import PIPE


sys.path.insert(1, "/mnt/mnemo2/damian/DSutils/")
#sys.path.insert(1, "/g/bork1/szklarcz/DSutils/")

#from rrutils import rropen

def load_proteins(target_file, target_taxid):
    
    prots  = {}

    for line in open(target_file):
        l = line.strip().split("\t")

        prot  = int(l[0])
        prots[prot]   = 1
    
    print >> sys.stderr, "Protein list list loaded..."
    
    return prots
    

def load_tree(tree_file):
    tree = {}
    tree_down = {}
    for line in open(tree_file):
        l = line.strip().split("\t")
        taxid, parent_taxid = int(l[0]), int(l[1])
        tree[taxid] = parent_taxid
        
        if parent_taxid not in tree_down:
            tree_down[parent_taxid] = {}
        tree_down[parent_taxid][taxid] = 1

    return tree, tree_down


def load_level_similarities(level_similarity_file):
    level_similarity = {}
    for line in open(level_similarity_file):
        l = line.strip().split("\t")
        taxid, similarity = int(l[0]), float(l[1])
        level_similarity[taxid] = similarity
        
    return level_similarity

def is_child(child_taxid, parent_taxid, tree_up):
    taxid = tree_up[child_taxid]
    
    if child_taxid == parent_taxid:
        return True
    
    if taxid == parent_taxid:
        return True
    elif taxid == 1:
        return False
    else:
        return is_child(taxid, parent_taxid, tree_up)    



def get_direct_child(target_taxid, og_taxid, tree_up, tree_down):
    
    for og_child in tree_down[og_taxid]:
        
        if is_child(target_taxid, og_child, tree_up):
            direct_child = og_child
        
    return direct_child
    

def load_ogs(orthogroup_file,  target_taxid, tree):
    
    ogs_prots = {}
    prots_ogs = {}
 
    for line in open(orthogroup_file):
        l = line.strip().split("\t")
        
        og, prot_taxid, prot = l
        prot, taxid  = int(prot), int(prot_taxid)
        
        if taxid == target_taxid:          
            
            if prot not in prots_ogs:
                prots_ogs[prot] = {}
            prots_ogs[prot][og] = 1
            
            if og not in ogs_prots:
                ogs_prots[og] = {}
            ogs_prots[og][prot] = 1            
            
    print >> sys.stderr, "ogs prot mapping loaded..."

    og_target_tax_fraction = {}
    for og in ogs_prots:
        og_target_tax_fraction[og] = 1/float(len(ogs_prots[og]))
    
    
    return prots_ogs, ogs_prots, og_target_tax_fraction

    
    

def load_ogs_for_ogs_transfer(orthogroup_file, prots, target_taxid, tree):
    
    ogs_prots = {}
    prots_ogs = {}
    
    expend_taxid_to_protein_taxid(target_taxid, tree)
 
    for line in open(orthogroup_file):
        l = line.strip().split("\t")
        
        og, prot_taxid, prot = l
        prot, taxid  = int(prot), int(prot_taxid)
                
        if prot in prots:
            
            if prot not in prots_ogs:
                prots_ogs[prot] = {}
            prots_ogs[prot][og] = 1
            
            if og not in ogs_prots:
                ogs_prots[og] = {}
            ogs_prots[og][prot] = 1            
            
    print >> sys.stderr, "ogs prot mapping loaded..."

    og_target_tax_fraction = {}
    for og in ogs_prots:
        og_target_tax_fraction[og] = 1/float(len(ogs_prots[og]))
    
    
    return prots_ogs, ogs_prots, og_target_tax_fraction





def load_scores(og_og_scores_file, blocked, ogs_prots, target_part_taxid):
    
    og_og_scores_taxid = {}
    
    og_taxid = int(os.path.basename(og_og_scores_file).split(".")[0])
        
    print >> sys.stderr, "Loading og og scores at %s..." % og_taxid ,
    c = 0
    
    start = time.time()
    for line in open(og_og_scores_file):
        line = line.strip()
        l = line.split("\t")
        
        og1, part_taxid, og2, kind, score = l[0], int(l[2]), l[3], l[4], l[5]
        
        channel = kind.split()[1]
        
        if blocked:
            if channel in blocked:
                continue
        
        if ((part_taxid == og_taxid) or
            (part_taxid == target_part_taxid)):
            
            if og1 in ogs_prots:
                
                score = float(score)
                
                if og1 not in og_og_scores_taxid:
                    og_og_scores_taxid[og1] = {}
                    
                if og2 not in og_og_scores_taxid[og1]:
                    og_og_scores_taxid[og1][og2] = {}
                            
                if kind not in og_og_scores_taxid[og1][og2]:
                    og_og_scores_taxid[og1][og2][kind] = {}
                
                og_og_scores_taxid[og1][og2][kind][part_taxid] = score
                
    finish = time.time()
    
    print >> sys.stderr, "done."
    print >> sys.stderr, "Duration: ", int(finish-start)
    return og_og_scores_taxid

            
def combine_two_scores(score1, score2):
    return (1 -
                ( (1-px) * ( # adding px
                    ((1-score1)/(1-px)) * 
                    ((1-score2)/(1-px))
                ) )
            )


def substract_scores(score1, score2):
    if score2 == 1 or score1 == score2: return px
    else:
        return (1 -
                    ( (1-px) * ( # adding px
                        ((1-score1)/(1-px)) / 
                        ((1-score2)/(1-px))
                    ) )
                )
