from subprocess import Popen
from subprocess import PIPE
import os
import sys
#from rrutils import rropen
max_processes = 20

from multiprocessing import Process
import subprocess

from time import sleep


run_dir     = "/mnt/mnemo2/damian/string/maintenance/transfer/string/string_v10_5/"
derived_dir = "/mnt/mnemo4/damian/STRING_v10_5/STRING_derived_v10_5/transfer/"


def format_channel(input_file, output_file, species, channel, protid_prot):
    
    print input_file
    print output_file
    print species
    print channel
    print len(protid_prot)

    
    fh_out = open(output_file+".inprocess", "w")
    
    if channel in ["textmining", "array", "equiv", "experimental"]:
        
        tag = channel+"_transferred"
        
        header = True
        
        for line in open(input_file):
            
            if header and line.startswith("#"):
                continue
            else:
                header = False
            
            l = line.strip().split("\t")
            sp, protid1, protid2, undef, score = l
            
            prot1 = protid_prot.get(protid1)
            prot2 = protid_prot.get(protid2)
            
            if prot1 and prot2:
                print >> fh_out, "\t".join([tag, sp, prot1, prot2, score])
    
    
    
    if channel == "database":
        
        for line in open(input_file):
            
            l = line.strip().split("\t")
            sp, protid1, protid2, tag, score = l
            tag = tag.split()[-1]
            
            prot1 = protid_prot.get(protid1)
            prot2 = protid_prot.get(protid2)
            
            if prot1 and prot2:
                print >> fh_out, "\t".join([tag, sp, prot1, prot2, score])
    
    if channel == "actions":
        
        tag = "actions_transferred"
        for line in open(input_file):
            
            l = line.strip().split("\t")
            sp, protid1, protid2, mode_action, score = l
            
            mode, action = mode_action.split()
            
            action, is_directional, a_is_acting = action.split("_")
            
            prot1 = protid_prot.get(protid1)
            prot2 = protid_prot.get(protid2)
            
            if prot1 and prot2:
                print >> fh_out, "\t".join([tag, sp, prot1, prot2, score, mode, action, is_directional, a_is_acting])


    fh_out.close()    
    os.system("mv " + output_file+".inprocess " + output_file )



channels = [
    #"textmining",
    #"array",
    #"experimental",
    "equiv",
    #"database",
    #"actions",
]


sp_protid_prot = {}
for line in open(derived_dir+"protein.shorthands.txt"):
    sp_prot, protid = line.strip().split("\t")
    sp, prot = sp_prot.split(".", 1)
    
    if sp not in sp_protid_prot:
        sp_protid_prot[sp] = {}
    
    sp_protid_prot[sp][protid] = prot

init_params = []

for channel in channels:

    input_dir   = derived_dir + "/transfer_output/" + channel + "_calibrated/"
    output_dir  = derived_dir + "/transfer_output/" + channel + "_formatted/"
    
    if not os.path.exists(output_dir):
        os.system("mkdir " + output_dir)

    
    for file_ in os.listdir(input_dir):
        if channel in file_:
            
            species = file_.split(".")[0]
            
            input_file  = input_dir  + file_
            output_file = output_dir + species + "." + channel + "_trasnferred_interact.tsv"
            
            init_params.append( (input_file, output_file, species, channel, sp_protid_prot[species]) )
            

processes = {}

for process_num in range(max_processes):
            
    if len(init_params):        
        init_param = init_params.pop(0)
        
        print >> sys.stderr, "Initiating process (initial) %d" % process_num
        processes[process_num] = Process(target=format_channel, args=init_param)
        processes[process_num].start()
        
        sleep(0.1)


if len(init_params):
    while True:
        
        for process_num, process in processes.iteritems():
            if not process.is_alive():
                print >> sys.stderr, "Initiating process in spot %d" % process_num
                init_param = init_params.pop(0)
                processes[process_num] = Process(target=format_channel, args=(init_param))
                processes[process_num].start()
                sleep(0.1)
                
            if len(init_params) == 0: break
        if len(init_params) == 0: break

#
# Wait till processes finish
#

print >> sys.stderr, "Waiting for processes to finish..."

while True:
    still_running = False
    for process_num, process in processes.iteritems():        
        if process.is_alive():
            still_running = True
    
    if not still_running:
        break
    
    sleep(1)

print >> sys.stderr, "Finished executing...."

sys.exit()










