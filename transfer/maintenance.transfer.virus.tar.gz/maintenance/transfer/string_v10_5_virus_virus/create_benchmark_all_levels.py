#!/usr/bin/env python

#
# Create benchamrk sets for all the levels
#



import os
import sys

sys.path.insert(1, "/g/bork1/szklarcz/DSutils/")

from rrutils import rropen
from operator import itemgetter


kegg_benchmarking_orig  = "/g/scb/bork/mering/STRING_derived_v10_5/kegg/kegg_benchmarking.CONN_maps_in.v10.tsv"
#kegg_benchmarking_ids   = "/mnt/mnemo3/damian/STITCHv5/transfer_experiments/derived/kegg_benchmarking.CONN_maps_in.ids.tsv"

prot_shorthands         = "/g/scb/bork/mering/STRING_derived_v10_5/proteins.shorthands.v10_5.tsv"
og_path                 = "/g/scb/bork/mering/STRING_derived_v10_5/transfer/orthogroups_protids/"
benchmark_path          = "/g/scb/bork/mering/STRING_derived_v10_5/kegg/benchmark_levels/"
nodes_file              = "/g/scb/bork/mering/STRING_derived_v10_5/transfer/string_v10.levels_species.tsv"
tree_file               = "/g/scb/bork/mering/STRING_derived_v10_5/transfer/eggNOG_tree.tsv"

# Load shorthands

prot_protid = {}
protid_prot = {}
prots_sp   = {}

for line in rropen(prot_shorthands):
    protid, prot = line.strip().split("\t")
    
    sp  = prot.split(".", 1)[0]
    
    prot_protid[prot] = protid
    prot_protid[protid] = prot
    
    prots_sp[protid] = sp
    
# Load all the nodes

nodes = {}
for line in rropen(nodes_file):
    l = line.strip().split("\t")
    level = l[0]
    sps   = l[1].split()
    
    # Species as well
    nodes[level] = {}
    for sp in sps:
        nodes[level][sp] = 1


for sp in nodes["1"]:
    nodes[sp] = {}
    nodes[sp][sp] = 1
    
# Load tree

parent_taxid = {}
for line in rropen(tree_file):
    l = line.strip().split("\t")
    child, parent = l[0], l[1]
    parent_taxid[child] = parent


# Load full benchmarking file
species_present = {}
prots_keggs     = {}


def strip_kegg_prefix(kegg):
    
    def sst(kegg):
        if kegg[3].isdigit:
            return kegg[3:]
        else:
            return kegg[4:]
        
    if kegg[:4] == "CONN":
        kegg_p1, kegg_p2 = kegg[5:].split("_")
        kegg = sst(kegg_p1) + "_" + sst(kegg_p2)
        
    else:
        kegg = sst(kegg)
    
    return kegg



def strip_chem_prefix(chem):
    chem = chem[3:]
    if chem[0] == "1":
        return "CID" + chem
    else:
        return "CID" + chem.lstrip("0")
            

keggs_chems = {}
print >> sys.stderr, "Loading kegg maps and proteins...",
for line in rropen(kegg_benchmarking_orig):
    
    l = line.strip().split("\t")
    
    if len(l) == 4:
        sp   = l[0]
        kegg = l[1]
        
        # We need to know which species are present in kegg
        
        species_present[sp] = 1
        
        kegg = strip_kegg_prefix(kegg)
        
        for prot in l[3].split():
            if prot.startswith("CID1") or prot.startswith("CID0"):
                chem = strip_chem_prefix(prot)
                 
                if kegg not in keggs_chems: keggs_chems[kegg] = {}
                keggs_chems[kegg][chem] = 1
            else:
                prot = sp + "." + prot
                protid = prot_protid[prot]
                if protid not in prots_keggs: prots_keggs[protid] = {}
                prots_keggs[protid][kegg] = 1
            
print >> sys.stderr, "finished"


level_ogs_prots  = {}
level_prots_ogs  = {}
level_og_kegg    = {}
keggs_ogs        = {}


#for line in rropen(og_path + "%s.orthgroups_string.tsv" % level):
for og_file in os.listdir(og_path):
    
    level = og_file.split(".")[0]
    
    for line in rropen(og_path + og_file):
        
        l = line.strip().split("\t")
            
        og, prot_taxid, prot = l
                
        if level not in level_ogs_prots:
            level_ogs_prots[level] = {}
            level_prots_ogs[level] = {}
        
        if og not in level_ogs_prots[level]:
            level_ogs_prots[level][og] = {}
            
        if prot not in level_prots_ogs[level]:
            level_prots_ogs[level][prot] = {}
        
        level_ogs_prots[level][og][prot] = 1
        level_prots_ogs[level][prot][og] = 1
        


print >> sys.stderr, "finished"


nodes_length = [(level, len(sps)) for level,sps in nodes.iteritems()]

# For all the levels    
# Sorted from the largest one, so we can always skip one level up
# to pull the corresponding og that potentially has map assigned


for level, length in sorted(nodes_length, key=itemgetter(1), reverse=True):
    print >> sys.stderr, "Loading orthogroups for %s..." % level,
     
    #We need to find level up
    # As we have sorted nodes we already loaded higher level
    
    if level != "1":
        level_up = parent_taxid[level]
        while level_up not in nodes:
            level_up = parent_taxid[level]

    print >> sys.stderr, "Assigning maps to ogs....",
    
    if len(nodes[level]) > 1:

        # We have og level
        # For every og in this level
        
        for og in level_ogs_prots[level]:
            
            count         = 0
            kegg_assigned = {}
            
            for prot in level_ogs_prots[level][og]:
                prot_taxid = prots_sp[prot]
                
                if prot_taxid not in species_present:
                    if level == "1":
                        continue # If it's highest level we pass
                    else:
                        # We assign to the prot whatever maps were assigned in the higher level
                        # to the og that the prot belong to
                        assigned = False
                        if prot in level_prots_ogs[level_up]:
                            if prot in level_prots_ogs[level_up]:
                                for parent_og in level_prots_ogs[level_up][prot]:
                                    if parent_og in level_og_kegg[level_up]:
                                        prots_keggs[prot] = level_og_kegg[level_up][parent_og].keys()
                                        assigned = True
                                        #print prot, level_up, parent_og, level_og_kegg[level_up][parent_og].keys()
                                        
                        if not assigned:
                            prots_keggs[prot] = {}
    
                count += 1 # We add map count even if the protein doesn't have any map assigned, but we have this species.         
                
                if prot in prots_keggs:
                    for kegg in prots_keggs[prot]:
                        if kegg not in kegg_assigned:
                            kegg_assigned[kegg] = 0
                        kegg_assigned[kegg] += 1
        
            for kegg in kegg_assigned:
                if kegg_assigned[kegg] >= count/2.0:
                    
                    if kegg not in keggs_ogs:
                        keggs_ogs[kegg] = {}
                        
                    if level not in keggs_ogs[kegg]:
                        keggs_ogs[kegg][level] = {}
                    
                    if level not in level_og_kegg:
                        level_og_kegg[level] = {}
                    if og not in level_og_kegg[level]:
                        level_og_kegg[level][og] = {}
    
                    keggs_ogs[kegg][level][og] = 1
                    level_og_kegg[level][og][kegg] = 1

        print >> sys.stderr, "finished"
    # If it's protein level
    else:
        for prot in prots_keggs:
            sp = prots_sp[prot]
            if sp == level:
                for kegg in prots_keggs[prot]:
                    if kegg not in keggs_ogs:
                        keggs_ogs[kegg] = {}
                    if level not in keggs_ogs[kegg]:
                        keggs_ogs[kegg][level] = {}
                     
                    keggs_ogs[kegg][level][prot] = 1
        print >> sys.stderr, "finished"
        
    #if not assigned:
            
    
    fh_out = rropen(benchmark_path+"/%s.benchmark_kegg.tsv" % level, "w")
    for kegg in keggs_ogs:
        if level in keggs_ogs[kegg]:
            if len(keggs_ogs[kegg][level]) > 0:
                chems = keggs_chems[kegg].keys() if kegg in keggs_chems else []
                print >> fh_out,  level + "\t" + kegg + "\t" + " ".join(keggs_ogs[kegg][level].keys() + chems)
                
                    
    fh_out.close()        
        
#add_prot_ids_to_kegg()
#create_og_benchmark()

