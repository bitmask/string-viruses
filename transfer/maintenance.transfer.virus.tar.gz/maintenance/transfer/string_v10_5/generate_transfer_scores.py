#!/usr/bin/env python
import os
import sys
import utils_transfer
import time
import subprocess
import pprint

#sys.path.insert(1, "/g/bork1/szklarcz/DSutils/")
sys.path.insert(1, "/mnt/mnemo2/damian/DSutils/")

import argparse
#from rrutils import rropen


#### Load arguments:

p = argparse.ArgumentParser()


p.add_argument("--input", \
               help='list of proteins', required=True, type=str)

p.add_argument("--alpha", \
               help='alpha (fraction penalty)', \
               required=True, type=float)

p.add_argument("--beta", \
               help='beta (level similarity penalty)', \
               required=True, type=float)

p.add_argument("--gocs_folder", \
               help='gocs directory', required=True, type=str)

p.add_argument("--gocs_suffix", \
               help='gocs directory', required=True, type=str)

p.add_argument("--output", \
               help='output file', required=True, type=str)

p.add_argument("--tree", \
               help='tree file', \
               required=True, type=str)

p.add_argument("--hogs_map", \
               help='host orthogroups mapping directory', \
               required=True, type=str)

p.add_argument("--vogs_map", \
               help='virus orthogroups mapping directory', \
               required=True, type=str)

p.add_argument("--sim", \
               help='level similarity', \
               required=True, type=str)

p.add_argument("--blocked", \
               help='blocked channel', \
               required=True, type=str)

p.add_argument("--directional", \
               help='blocked channel', \
               required=False, type=str)



args = p.parse_args()

px = 0.041

target_taxid          = int(args.input)
tree_file             = args.tree
level_similarity_file = args.sim
hprot_og_path         = args.hogs_map
vprot_og_path         = args.vogs_map
og_score_path         = args.gocs_folder
gocs_suffix           = args.gocs_suffix
alpha                 = args.alpha
beta                  = args.beta
blocked               = args.blocked

if blocked == "NA":
    blocked = 0
else:
    blocked = blocked.split(",")

retain_directionality = False

if args.directional:
    if args.directional == "True":
        retain_directionality = True


output_file_path = os.path.dirname(args.output)
output_file_name = os.path.basename(args.output)

output_file     = args.output
inproc_file     = output_file_path + "/inprocess." + output_file_name

print "writing output to " + output_file


utils_transfer.px = px
#prots            =  utils_transfer.load_proteins(target_file, target_taxid) There are no prots now.
tree, tree_down  =  utils_transfer.load_tree(tree_file)
level_similarity =  utils_transfer.load_level_similarities(level_similarity_file)

prot_prot_comb_final = {} # Dict with final results


print >> sys.stderr, "### Script running with parameters: ###"
print >> sys.stderr, output_file, "\t output file"
print >> sys.stderr, str(round(alpha, 2)), "\t alpha"
print >> sys.stderr, str(round(beta, 2)), "\t beta"
print >> sys.stderr, "### End of parameters ###"


# virus levels
virus_levels = set()
for line in open("/mnt/mnemo4/helen/virus_transfer/transfer/virus.levels_species.tsv"):
    virus_levels.add(line.split("\t")[0])

parent_taxid = target_taxid

while parent_taxid != 1:
    
    parent_taxid = tree[parent_taxid]
    
    # Either we subtract target species score or the level below
    # In this case we subtract target_taxid
    part_taxid = target_taxid
    
    print >> sys.stderr, parent_taxid, time.ctime()
        
    # We have load all relevant ogs and mapping for viruses and hosts
    horthogroup_file   = hprot_og_path  + str(parent_taxid) + ".og_protid.tsv"

    og_og_scores_file = og_score_path + str(parent_taxid) + "." + gocs_suffix
    
    print og_og_scores_file
        
    hprots_ogs, hogs_prots, hog_target_tax_fraction = utils_transfer.load_ogs(horthogroup_file, target_taxid, tree, False)
    og_og_scores   = utils_transfer.load_scores(og_og_scores_file, blocked, hogs_prots, part_taxid)
    
    sim_level = level_similarity[parent_taxid]
    
    for prot1 in hprots_ogs:
        #print "prot 1 " + str(prot1)
        prot2_comb_current = {}
        
        for og1 in hprots_ogs[prot1]:
            #print "og 1 " + str(og1)
            if og1 in og_og_scores:
                
                f1 = hog_target_tax_fraction[og1]
                #print "f1 " + str(f1)
                
                sim1 = 1 # og similarity (not implemented)
                
                
                for og2 in og_og_scores[og1]:  # og2 == prot2 == chem
                    #print "og 2 " + str(og2)
                    
                    # now we have a viral og, find it in all the levels (ugh)
                    for vlevel in virus_levels:
                        vorthogroup_file   = vprot_og_path  + str(vlevel) + ".og_protid.tsv"
                        vprots_ogs, vogs_prots, vog_target_tax_fraction = utils_transfer.load_ogs(vorthogroup_file, vlevel, tree, True)

                        if og2 not in vogs_prots: continue
                        #print "vlevel " + str(vlevel)
                        
                        for prot2 in vogs_prots[og2]:
                            #print "prot 2 " + str(prot2)
                            
                            #if prot1 >= prot2 and not retain_directionality: continue
                            
                            f2 = vog_target_tax_fraction[og2]
    
                            fraction_modifier = ((sim1)**beta)
                            fraction_modifier = fraction_modifier*((f1*f2)**alpha) # this also
                            
                            for kind in og_og_scores[og1][og2]:
                                
                                taxid_scores = og_og_scores[og1][og2][kind]
                                
                                if parent_taxid in taxid_scores:
                                    full_score   = taxid_scores[parent_taxid]
                                    
                                    if part_taxid in taxid_scores:
                                        part_score = taxid_scores[part_taxid]
                                    else:
                                        part_score = px
                                    
                                    score = utils_transfer.substract_scores(full_score, part_score)
                                    score = fraction_modifier*score
                                    
                                    if score > px:
                                        
                                        if prot2 not in prot2_comb_current: # if we don't have anything for this guy.
                                            prot2_comb_current[prot2] = {}
                                        
                                        if kind not in prot2_comb_current[prot2]:
                                            prot2_comb_current[prot2][kind] = score
                                        else:
                                            comb_score = prot2_comb_current[prot2][kind]
                                            comb_score = utils_transfer.combine_two_scores(comb_score, score)
                                            prot2_comb_current[prot2][kind] = comb_score
    
        
        if prot1 not in prot_prot_comb_final:
            prot_prot_comb_final[prot1] = {}
        
        # This is when we combine scores for different levels (from bottom to top)
        # Hence we combine only the reminder of the root-ward level
        for prot2 in prot2_comb_current:
            
            for kind in prot2_comb_current[prot2]:
                
                trans_score = prot2_comb_current[prot2][kind]
                
                if prot2 not in prot_prot_comb_final[prot1]:
                    prot_prot_comb_final[prot1][prot2] = {}
                    
                if kind not in prot_prot_comb_final[prot1][prot2]:
                    prot_prot_comb_final[prot1][prot2][kind] = trans_score
                else:
                    comb_score = prot_prot_comb_final[prot1][prot2][kind]
                    
                    if trans_score > comb_score:
                                        
                        final_trans_score = utils_transfer.substract_scores(trans_score, comb_score) # get reminder
                        
                        if final_trans_score > px:
                            
                            comb_score = utils_transfer.combine_two_scores(comb_score, final_trans_score)
                            prot_prot_comb_final[prot1][prot2][kind] =  comb_score


output_fh = open(inproc_file, "w")
for prot1 in prot_prot_comb_final:
    for prot2 in prot_prot_comb_final[prot1]:
        for kind in prot_prot_comb_final[prot1][prot2]:
            
            print >> output_fh, "\t".join([str(target_taxid), str(prot1), str(prot2), kind, str(prot_prot_comb_final[prot1][prot2][kind])])
            if not retain_directionality:
                print >> output_fh, "\t".join([str(target_taxid), str(prot2), str(prot1), kind, str(prot_prot_comb_final[prot1][prot2][kind])])

output_fh.close()
subprocess.Popen("mv %s %s" % (inproc_file, output_file), shell=True).wait()





