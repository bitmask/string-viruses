#!/usr/bin/env python


dbdump    = "/g/scb/bork/mering/STRING_derived_v10_5/transfer/network.node_node_links.v10_5.dump"
outfile = "/g/scb/bork/mering/STRING_derived_v10_5/transfer/full_%s.tsv"

scores_to_extract = {
    "1" : "equiv_nscore",
    "6" :  "array_score",
    "8" :  "experimental_score",
    "10" : "database_score",
    "12" : "textmining_score"
}


fhs = {}
for iscore in scores_to_extract:
    fhs[iscore] = open(outfile % scores_to_extract[iscore], "w")

c = 0
for line in open(dbdump):

    l = line.strip().split("\t")

    if len(l) < 5:  continue

    prot1, sp, prot2, cscore, scores = l
    
    scores = scores.split("},{")
    for chscore in scores:
        ch, score = chscore.strip("{}").split(",")
        if ch in fhs:
            line = "\t".join([sp, prot1, prot2, ch, ch, str(float(score)/1000)])
            print >> fhs[ch], line

for ch in fhs:
    fhs[ch].close()
    

