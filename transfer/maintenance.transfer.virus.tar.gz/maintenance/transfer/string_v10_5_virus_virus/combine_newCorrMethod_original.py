import os
import sys
import gzip
import math

derived_dir = "/mnt/mnemo2/damian/STRING_v10/sources_combine_new/derived/"
input_dir   = "/mnt/mnemo2/damian/STRING_v10/sources_combine_new/input/"
all_scores_file =  input_dir + "4932.protein.links.full.v10.txt.gz"
benchmark_file  =  input_dir + "4932.kegg_benchmarking.CONN_maps_in.v10.tsv"


def pearson(x,y):
    mx = sum(x)/max(len(x), 1)
    my = sum(x)/max(len(x), 1)
    
    cov = 0
    sdx = 0
    sdy = 0
    for i in range(len(x)):
        xi = x[i]
        yi = y[i]
        cov += (xi-mx)*(yi-my)
        sdx += (xi-mx)*(xi-mx)
        sdy += (yi-my)*(yi-my)
        
    sdx = math.sqrt(sdx)
    sdy = math.sqrt(sdy)
    
    if sdx == 0 or sdy == 0:
        return 0
    r = cov/(sdx*sdy)
    
    return r

px = 0.041

def load_benchmark():
    
    prot_kegg = {}
    
    for line in open(benchmark_file):
        
        level, kegg, _, prots = line.strip().split("\t")
        
        for prot in prots.split():
            
            prot = level+"."+prot
            
            if prot not in prot_kegg:
                prot_kegg[prot] = set()
            prot_kegg[prot].add(kegg)
    
    return prot_kegg


def combine_two_scores(score1, score2):
    
    return (1 -
                ( (1-px) * ( # adding px
                    ((1-score1)/(1-px)) * 
                    ((1-score2)/(1-px))
                ) )
            )


def combine_two_scores_with_rho(score1, score2, curr_index, combined_indexes, rho_table):
    
    max_rho = 0
    for comb_index in combined_indexes:
        
        if rho_table[curr_index][comb_index] > max_rho:
            
            max_rho = rho_table[curr_index][comb_index]

    
    score1 = 1 - (1-score1)/(1-px) # remove prior
    score2 = 1 - (1-score2)/(1-px)

    comb_score = (1-score1)*(1-score2) # combine scores
    
    comb_score = 1 - (comb_score + max_rho * math.sqrt(score1*(1-score1) * score2*(1-score2) )  ) # add r +ho
    
    comb_score = 1 - (1-px)*(1-comb_score) # add prior
    
    
    return comb_score

def load_orig_combined_score():

    index = -1
    first_line = True
    
    pp_score = {}
    for line in gzip.open(all_scores_file):
        
        if first_line:
            first_line = False
            continue
        l = line.strip().split()
        p1,p2,score = l[0], l[1], l[index]
        if p1 < p2:
            if p1 not in pp_score:
                pp_score[p1] = {}
            pp_score[p1][p2] = score
    
    return pp_score

"""
0:protein1
1:protein2
2:neighborhood
3:neighborhood_transferred
4:fusion
5:cooccurence
6:homology
7:coexpression
8:coexpression_transferred
9:experiments
10:experiments_transferred
11:database
12:database_transferred
13:textmining
14:textmining_transferred
15:combined_score
"""
#indexes = [2,4,5,7,9,11,13] 
indexes = [2,3,4,5,7,8,9,10,11,12,13,14]
indexes = [14,13,12,11,10,9,8,7,5,4,3,2]
#indexes = [2,3,4,5,7,9,10,12,13,14]
#indexes = [9,10]
#indexes = [8,10]


def create_rho_table():

    rho_table_file = derived_dir+"/rho_table.tsv"
    
    if not os.path.exists(rho_table_file):
        fh_out = open(rho_table_file, "w")
        #indexes = [2,4,5,7,9,11,13]  # direct
        #indexes = [2,3,4,5,7,8,9,10,11,12,13,14] # all
        
        first_line = True
        pp_type_score = {}
        
        for line in gzip.open(all_scores_file):
            
            if first_line:
                first_line = False
                continue
            
            l = line.strip().split()
            p1,p2= l[0], l[1]
            
            if p1 < p2:
                
                for index in indexes:
                    
                    score = float(l[index])/1000
                    
                    if score > px:
                                                        
                        if p1 not in pp_type_score:
                            pp_type_score[p1] = {}
                        if p2 not in pp_type_score[p1]:
                            pp_type_score[p1][p2] = {}
                            
                        pp_type_score[p1][p2][index] = score
        
        
        for index1 in indexes:
            for index2 in indexes:
                if index1 < index2:
                    m1 = []
                    m2 = []
                    for p1 in pp_type_score:
                        
                        for p2, present_indexes in pp_type_score[p1].iteritems():
                            
                            if index1 in present_indexes and index2 in present_indexes:
                                m1.append(present_indexes[index1])
                                m2.append(present_indexes[index2])
                    
                    print >> fh_out, "\t".join([str(index1), str(index2), str(pearson(m1, m2))])
        fh_out.close()
    rho_table = {}
    
    for line in open(rho_table_file):
        l = line.strip().split("\t")
        i1, i2, rho = l
        for i1, i2 in [ (int(i1), int(i2)), (int(i2), int(i1))]:
            if i1 not in rho_table:
                rho_table[i1] = {}
            rho_table[i1][i2] = float(rho)
    
    return rho_table
        
def load_indexes_combined_score():

    
    first_line = True
    pp_score = {}
    
    for line in gzip.open(all_scores_file):
        
        if first_line:
            first_line = False
            continue
        
        l = line.strip().split()
        p1,p2= l[0], l[1]
        
        if p1 < p2:
            
            combined_score = px
            
            for index in indexes:
                score = float(l[index])/1000
                if score > px:
                    combined_score = combine_two_scores(combined_score, score)
                                                    
            if p1 not in pp_score:
                pp_score[p1] = {}
            pp_score[p1][p2] = combined_score
    
    return pp_score

def load_combined_score_with_rho(rho_table):

    
    first_line = True
    pp_score = {}
    
    for line in gzip.open(all_scores_file):
        
        if first_line:
            first_line = False
            continue
        
        l = line.strip().split()
        p1,p2= l[0], l[1]
        
        if p1 < p2:
            
            combined_indexes = []
            combined_score = px
            
            for index in indexes:
                score = float(l[index])/1000
                if score > px:
                    combined_score = combine_two_scores_with_rho(combined_score, score, index, combined_indexes, rho_table)
                    combined_indexes.append(index)
                                                    
            if p1 not in pp_score:
                pp_score[p1] = {}
            pp_score[p1][p2] = combined_score
    

    
    return pp_score



def print_probabilities(pp_score):
    bin_ratio = 5
    bins = []
    
    for i in range(0, 100, bin_ratio):
        bins.append([])
        
    for prot1 in pp_score:
        for prot2, score in pp_score[prot1].iteritems():
            
            if prot1 in prot_kegg and prot2 in prot_kegg:
            
                
                bin_index = int((((score*100)-0.001)/bin_ratio))
                
                share_kegg = 0
                for kegg in prot_kegg[prot1]:
                    if kegg in prot_kegg[prot2]:
                        share_kegg = 1
                        break
                    
                bins[bin_index].append(share_kegg)
    
    
    sum_norm = 0
    for bin_index in range(len(bins)):
        if len(bins[bin_index]) != 0:
            tf_ratio = sum(bins[bin_index])/float(len(bins[bin_index]))
            
            
            print "\t".join([str(bin_index*bin_ratio+float(bin_ratio)/2),
                             str(tf_ratio),
                             str(len(bins[bin_index])),
                             str(len(bins[bin_index])*tf_ratio)])
            sum_norm+=len(bins[bin_index])*tf_ratio
    
    print sum_norm
    

prot_kegg = load_benchmark()
rho_table = create_rho_table()

pp_score  = load_combined_score_with_rho(rho_table)
print_probabilities(pp_score)

#pp_score  = load_indexes_combined_score()
#print_probabilities(pp_score)
























