#!/usr/bin/env python

import os
import sys
import time
import subprocess
import gzip
from rrutils import rropen

if len(sys.argv) != 2:
    sys.exit("Wrong parameters.\nShould be: input_file benchmark_file")
    
input_file  = sys.argv[1]
input_sp    = os.path.basename(input_file).split(".")[0]


if not input_sp.isdigit():
    sys.exit("file doesn't have species prefix")

kegg_file   = "/mnt/mnemo2/damian/compute_scores10/derived/benchmark_levels/%s.benchmark_kegg.tsv" % input_sp

prot_kegg = {}

for line in rropen(kegg_file):
    level, kegg, prots = line.strip().split("\t")
    for prot in prots.split():
        
        if prot not in prot_kegg:
            prot_kegg[prot] = set()
        prot_kegg[prot].add(kegg)


prot_prot_score = {}
for line in rropen(input_file, gz=True):
    
    prot1, prot2, score = line.strip().split("\t")
    
    if prot1 < prot2:
        
        if prot1 in prot_kegg and prot2 in prot_kegg:
            prot_prot_score[prot1 + "\t" + prot2] = float(score)
        
        
prot_prot_score_sorted = sorted(prot_prot_score.iteritems(), key=lambda x: x[1], reverse=True)


if not os.path.exists(os.path.join(os.path.dirname(input_file), "../rocs/")):
    os.system("mkdir %s" % os.path.join(os.path.dirname(input_file), "../rocs/"))

roc_file = os.path.join(os.path.dirname(input_file), "../rocs/", os.path.basename(input_file.rsplit(".", 1)[0]+".roc"))
roc_fh   = rropen(roc_file, "w") 
x, y = 0, 0

for prot_prot, score in prot_prot_score_sorted:
    
    prot1, prot2 = prot_prot.split()
    
    same_map = False
    for kegg in prot_kegg[prot1]:
        if kegg in prot_kegg[prot2]:
            same_map = True
    
    if same_map: y+=1
    else:        x+=1
    
    print >> roc_fh, "%d\t%d" % (x, y)

roc_fh.close()




