#!/usr/bin/env python
import os
valid_protids = set()
for line in open("/g/scb/bork/mering/STRING_derived_v10_5/proteins.shorthands.v10_5.tsv"):
    pid = line.split()[0]
    valid_protids.add(pid)
    
for file in os.listdir("/g/scb/bork/mering/STRING_derived_v10_5/transfer/orthogroups_protids_before_haploduplication/"):
    fh_out = open("/g/scb/bork/mering/STRING_derived_v10_5/transfer/orthogroups_protids/"+file, "w")
    
    for line in open("/g/scb/bork/mering/STRING_derived_v10_5/transfer/orthogroups_protids_before_haploduplication/"+file):
        if line.startswith("#"): continue
        
        prot = line.strip().split()[2]
        
        if prot in valid_protids:
            fh_out.write(line)
        else:
            print line,
    
    fh_out.close()
    