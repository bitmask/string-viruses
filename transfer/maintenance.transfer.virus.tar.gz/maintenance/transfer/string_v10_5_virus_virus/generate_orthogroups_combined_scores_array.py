#!/usr/bin/env python

####################################################
# This script generates orthogroup-orthogroup links
# by combining protein scores
# Memmory usage.. about 3GB per job
####################################################

import os
import sys
import time
import subprocess
import gzip

sys.path.insert(1, "/g/bork1/szklarcz/DSutils/")

import argparse
import utils_gocs_array as utils_gocs

#utils_gocs.rropen  = rropen
#utils_gocs.rrutils = rrutils

#################
# Load parameters
#################

p = argparse.ArgumentParser()

p.add_argument("--output", \
               help='output file', required=True, type=str)

p.add_argument("--beta", \
               help='exponent of fraction penalty (f1*f2)^beta', \
               required=True, type=float)

p.add_argument("--delta", \
               help='similarity penalty (slope/offset?)', \
               required=True, type=float)

p.add_argument("--gamma", \
               help='similarity penalty (slope/offset?)', \
               required=True, type=float)

p.add_argument("--ogs_list", \
               help='file with the list of the ogs to compute', \
               required=True, type=str)

p.add_argument("--ogs_map", \
               help='orthogroups mapping directory', \
               required=True, type=str)

p.add_argument("--prot_links", \
               help='protein links directory', \
               required=True, type=str)

p.add_argument("--tree", \
               help='tree file', \
               required=True, type=str)

p.add_argument("--levels_species", \
               help='species file', \
               required=True, type=str)


p.add_argument("--score_name", \
               help='species file', \
               required=True, type=str)


p.add_argument("--substract_homology", \
               help='homology file', \
               required=True, type=str)

p.add_argument("--sim", \
               help='species similarity file', \
               required=True, type=str)


############
# Constants
############

px = 0.041

args = p.parse_args()

final_output = args.output

output_path, output_file  = os.path.split(final_output)

og_level = int(output_file.split(".")[0])

report_file = "report."+output_file
report_file = os.path.join(output_path,report_file)

output_file = "inprocess."+output_file
output_file = os.path.join(output_path,output_file)


######################
# Load ogs to compute
######################

taxids_ogs = {}
for line in open(args.ogs_list):
    l = line.strip().split()
    og = l[0]
        
    if og_level not in taxids_ogs: taxids_ogs[og_level] = {}
    taxids_ogs[og_level][og] = 1


utils_gocs.px = px
utils_gocs.orthogroups_mapping_dir = args.ogs_map
utils_gocs.tax_tree_file = args.tree
#utils_gocs.homology_dir = args.homology_dir
utils_gocs.score_name = args.score_name
utils_gocs.species_in_levels_file = args.levels_species

utils_gocs.species_similarity_file = args.sim
#utils_gocs.homology_substract_score_pos = homology_substract_score_pos
#utils_gocs.clades_file = clades_file
utils_gocs.protein_links_file = args.prot_links

#utils_gocs.connectivity_file_name = connectivity_file_name
#utils_gocs.connectivity_dir = connectivity_dir

utils_gocs.beta  = args.beta
utils_gocs.delta = args.delta
utils_gocs.gamma = args.gamma

print >> sys.stderr, "beta:, ",  args.beta
print >> sys.stderr, "delta:, ", args.delta
print >> sys.stderr, "gamma:, ", args.gamma


foo = open(output_file, "w")
fro = open(report_file, "w")

########################################################################
# Main loop
# We divide the computation by taxonomy level to optimaize memmory usage
########################################################################

for og_level in taxids_ogs:
        
    utils_gocs.load_everything(og_level, taxids_ogs[og_level])
    
    count = 0
    for og in taxids_ogs[og_level]: # for every og
        count += 1
        
        if count%100 == 0:
            print >> sys.stderr, count, time.ctime()
            sys.stderr.flush()
            sys.stdout.flush()
        
        # main computation... combine scores for all the partners
        combined_scores = utils_gocs.combine_scores(og, fro)
        
        # write the output
        
        for taxid in combined_scores:
            for partner in combined_scores[taxid]:
                for action_mode in combined_scores[taxid][partner]:
                    action_mode_str = utils_gocs.action_channels_to_str[action_mode]
                    score = combined_scores[taxid][partner][action_mode]
                    if score > px:
#TODO add virus og and virus species
                        foo.write("\t".join([str(og), str(og_level), str(taxid), str(partner), action_mode_str, str(score)]) + "\n")                    

foo.close()
fro.close()
subprocess.Popen("mv %s %s" % (output_file, final_output), shell=True)

print >> sys.stderr, args.beta, args.delta, args.gamma, args.ogs_list, "Done!"






