#!/usr/bin/env python
import os
import sys
import time
import subprocess
import gzip
    
transfer_file = "/g/scb/bork/mering/STRING_derived_v10_5/transfer/transfer_output/4932.transfer_textmining_0.0_0.4.tsv.gz"
direct_file   =  "/g/scb/bork/mering/STRING_derived_v10_5/transfer/full_textmining_score.tsv"

input_sp    = os.path.basename(transfer_file).split(".")[0]

if not input_sp.isdigit():
    sys.exit("file doesn't have species prefix")

#kegg_file   = "/mnt/mnemo2/damian/compute_scores10/derived/benchmark_levels/%s.benchmark_kegg.tsv" % input_sp

kegg_file = "/g/scb/bork/mering/STRING_derived_v10_5/kegg/kegg_benchmarking.CONN_maps_in.v10.tsv"
shorthands_file = "/g/scb/bork/mering/STRING_derived_v10_5/proteins.shorthands.v10_5.tsv"


prot_protid = {}
protid_prot = {}
for line in open(shorthands_file):
    protid, prot = line.strip().split("\t")
    sp, prot = prot.split(".", 1)
    
    if sp == input_sp:
        
        prot_protid[prot] = protid
        protid_prot[protid] = prot
        
prot_kegg = {}

for line in open(kegg_file):
    sp, kegg, _, prots = line.strip().split("\t")
    
    if sp == input_sp:
        for prot in prots.split():
            
            prot = prot_protid[prot]
            
            if prot not in prot_kegg:
                prot_kegg[prot] = set()
            prot_kegg[prot].add(kegg)


prot_prot_tscore = {}
for line in gzip.open(transfer_file):
    
    if line[0] == "#": continue
    
    _, prot1, prot2, _, score = line.strip().split("\t")
    
    if prot1 < prot2:
        
        if prot1 in prot_kegg and prot2 in prot_kegg:
            prot_prot_tscore[prot1 + "\t" + prot2] = float(score)

prot_prot_dscore = {}
for line in open(direct_file):
    
    _, prot1, prot2, _, _, score = line.strip().split("\t")
    
    if prot1 < prot2:
        
        if prot1 in prot_kegg and prot2 in prot_kegg:

            prot_prot_dscore[prot1 + "\t" + prot2] = float(score)

def combine_two_scores(score1, score2):
    px = 0.041
    return (1 -
                ( (1-px) * ( # adding px
                    ((1-score1)/(1-px)) * 
                    ((1-score2)/(1-px))
                ) )
            )

prot_prot_cscore = {}
for pp, score in prot_prot_dscore.iteritems():
    

    if pp in prot_prot_tscore:
        score = combine_two_scores(score, prot_prot_tscore[pp])
        prot_prot_cscore[pp] = score



def print_probabilities(pp_score):
    bin_ratio = 5
    bins = []
    
    for i in range(0, 100, bin_ratio):
        bins.append([])
        
    for pp, score in pp_score.iteritems():
        prot1, prot2 = pp.split("\t")
            
                    
        bin_index = int((((score*100)-0.001)/bin_ratio))
        
        share_kegg = 0
        for kegg in prot_kegg[prot1]:
            if kegg in prot_kegg[prot2]:
                share_kegg = 1
                break
            
        bins[bin_index].append(share_kegg)
    
    
    sum_norm = 0
    for bin_index in range(len(bins)):
        if len(bins[bin_index]) != 0:
            tf_ratio = sum(bins[bin_index])/float(len(bins[bin_index]))
            
            
            print "\t".join([str(bin_index*bin_ratio+float(bin_ratio)/2),
                             str(tf_ratio),
                             str(len(bins[bin_index])),
                             str(len(bins[bin_index])*tf_ratio)])
            sum_norm+=len(bins[bin_index])*tf_ratio
    
    print sum_norm


for pp_scores in [prot_prot_dscore, prot_prot_tscore, prot_prot_cscore]:
    print_probabilities(pp_scores)
    print


        
#prot_prot_score_sorted = sorted(prot_prot_score.iteritems(), key=lambda x: x[1], reverse=True)
#
#
#if not os.path.exists(os.path.join(os.path.dirname(input_file), "../rocs/")):
#    os.system("mkdir %s" % os.path.join(os.path.dirname(input_file), "../rocs/"))
#
#roc_file = os.path.join(os.path.dirname(input_file), "../rocs/", os.path.basename(input_file.rsplit(".", 1)[0]+".roc"))
#roc_fh   = rropen(roc_file, "w") 
#x, y = 0, 0
#
#for prot_prot, score in prot_prot_score_sorted:
#    
#    prot1, prot2 = prot_prot.split()
#    
#    same_map = False
#    for kegg in prot_kegg[prot1]:
#        if kegg in prot_kegg[prot2]:
#            same_map = True
#    
#    if same_map: y+=1
#    else:        x+=1
#    
#    print >> roc_fh, "%d\t%d" % (x, y)
#
#roc_fh.close()
#






