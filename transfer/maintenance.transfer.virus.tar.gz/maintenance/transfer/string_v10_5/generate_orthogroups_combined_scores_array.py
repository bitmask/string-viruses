#!/usr/bin/env python

####################################################
# This script generates orthogroup-orthogroup links
# by combining protein scores
# Memmory usage.. about 3GB per job
####################################################

import os
import sys
import time
import subprocess
import gzip

sys.path.insert(1, "/g/bork1/szklarcz/DSutils/")

import argparse
import utils_gocs_array as utils_gocs

#utils_gocs.rropen  = rropen
#utils_gocs.rrutils = rrutils

#################
# Load parameters
#################

p = argparse.ArgumentParser()

p.add_argument("--output", \
               help='output file', required=True, type=str)

p.add_argument("--beta", \
               help='exponent of fraction penalty (f1*f2)^beta', \
               required=True, type=float)

p.add_argument("--delta", \
               help='similarity penalty (slope/offset?)', \
               required=True, type=float)

p.add_argument("--gamma", \
               help='similarity penalty (slope/offset?)', \
               required=True, type=float)

p.add_argument("--hogs_list", \
               help='file with the list of the host ogs to compute', \
               required=True, type=str)

p.add_argument("--vogs_list", \
               help='file with the list of the viral ogs to compute', \
               required=True, type=str)

p.add_argument("--hogs_map", \
               help='host orthogroups mapping directory', \
               required=True, type=str)

p.add_argument("--vogs_map", \
               help='virus orthogroups mapping directory', \
               required=True, type=str)

p.add_argument("--prot_links", \
               help='protein links directory', \
               required=True, type=str)

p.add_argument("--tree", \
               help='tree file', \
               required=True, type=str)

p.add_argument("--hlevels_species", \
               help='species file', \
               required=True, type=str)

p.add_argument("--vlevels_species", \
               help='viruses species file', \
               required=True, type=str)

p.add_argument("--score_name", \
               help='species file', \
               required=True, type=str)


p.add_argument("--substract_homology", \
               help='homology file', \
               required=True, type=str)

p.add_argument("--hsim", \
               help='species similarity file', \
               required=True, type=str)

p.add_argument("--vsim", \
               help='virus species similarity file', \
               required=True, type=str)
############
# Constants
############

px = 0.041

args = p.parse_args()

final_output = args.output

output_path, output_file  = os.path.split(final_output)

og_level = int(output_file.split(".")[0])

report_file = "report."+output_file
report_file = os.path.join(output_path,report_file)

output_file = "inprocess."+output_file
output_file = os.path.join(output_path,output_file)


######################
# Load ogs to compute
######################

# store hosts and viruses differently

taxids_hogs = {}
for line in open(args.hogs_list):
    l = line.strip().split()
    og = l[0]
        
    if og_level not in taxids_hogs: taxids_hogs[og_level] = {}
    taxids_hogs[og_level][og] = 1

# get all the virus orthology groups as array
taxids_vogs = []
for line in open(args.vogs_list):
    if not line.startswith("#"):
        l = line.strip().split()
        og = l[0]
        
        taxids_vogs.append(og)

utils_gocs.px = px
utils_gocs.horthogroups_mapping_dir = args.hogs_map
utils_gocs.vorthogroups_mapping_dir = args.vogs_map
    
utils_gocs.tax_tree_file = args.tree
#utils_gocs.homology_dir = args.homology_dir
utils_gocs.score_name = args.score_name
utils_gocs.host_species_in_levels_file = args.hlevels_species
utils_gocs.virus_species_in_levels_file = args.vlevels_species

utils_gocs.host_species_similarity_file = args.hsim
utils_gocs.virus_species_similarity_file = args.vsim
#utils_gocs.homology_substract_score_pos = homology_substract_score_pos
#utils_gocs.clades_file = clades_file
utils_gocs.protein_links_file = args.prot_links

#utils_gocs.connectivity_file_name = connectivity_file_name
#utils_gocs.connectivity_dir = connectivity_dir

utils_gocs.beta  = args.beta
utils_gocs.delta = args.delta
utils_gocs.gamma = args.gamma

print >> sys.stderr, "beta:, ",  args.beta
print >> sys.stderr, "delta:, ", args.delta
print >> sys.stderr, "gamma:, ", args.gamma


foo = open(output_file, "w")
fro = open(report_file, "w")

########################################################################
# Main loop
# We divide the computation by taxonomy level to optimaize memmory usage
# 
# for virus-host interactions,
# go through all host levels
# 
########################################################################

# go through the host ogs
for og_level in taxids_hogs:

    utils_gocs.load_everything(og_level, taxids_hogs[og_level], taxids_vogs)
    
    count = 0
    for og in taxids_hogs[og_level]: # for every host og
        count += 1
        
        if count%100 == 0:
            #print >> sys.stderr, count, time.ctime()
            sys.stderr.flush()
            sys.stdout.flush()
        
        # main computation... combine scores for all the partners
        combined_scores = utils_gocs.combine_scores(og, fro)
        
        # write the output
        
        for taxid in combined_scores:
            for vlevel in combined_scores[taxid]:
                for partner in combined_scores[taxid][vlevel]:
                    for action_mode in combined_scores[taxid][vlevel][partner]:
                        action_mode_str = utils_gocs.action_channels_to_str[action_mode]
                        score = combined_scores[taxid][vlevel][partner][action_mode]
                        if score > px:
    #TODO add virus og and virus species
                            foo.write("\t".join([str(og), str(vlevel), str(og_level), str(taxid), str(partner), action_mode_str, str(score)]) + "\n")                    

foo.close()
fro.close()
subprocess.Popen("mv %s %s" % (output_file, final_output), shell=True)

print >> sys.stderr, args.beta, args.delta, args.gamma, args.hogs_list, "Done!"






