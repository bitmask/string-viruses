#!/usr/bin/env python

import os
import sys

transfer_dir = "/mnt/mnemo4/damian/STRING_v10_5/STRING_derived_v10_5/transfer/"

cvm_primary_dir = transfer_dir+"/databases_from_cvm_primary/"
output_file = transfer_dir+"/full_database_score.unsorted_uniqued.tsv"
shorhands_file = transfer_dir+"/protein.shorthands.txt"

fh_out = open(output_file, "w")


prot_protid = {}

for line in open(shorhands_file):
    l = line.strip().split("\t")
    prot_protid[l[0]] = l[1]


for database in os.listdir(cvm_primary_dir):
    
    for interact_file in os.listdir(cvm_primary_dir+"/"+database):
        
        if "_interact.tsv." in interact_file:
            
            
            for line in open(cvm_primary_dir+"/"+database+"/"+interact_file):
            
                _, sp, prot1, prot2, score, _ = line.strip().split("\t")
                
                prot1 = ".".join([sp, prot1])
                prot2 = ".".join([sp, prot2])
                
                if prot1 in prot_protid and prot2 in prot_protid:
                    
                    pid1 = prot_protid[prot1]
                    pid2 = prot_protid[prot2]
                
                    print >> fh_out, "\t".join([sp, pid1, pid2, "10", database, score])

# DO NOT FORGET TO SORT UNIQ
fh_out.close()            
        
