from subprocess import Popen
from subprocess import PIPE
import os
import sys
import gzip
#from rrutils import rropen
max_processes = 5

from multiprocessing import Process
import subprocess

from time import sleep


run_dir     = "/mnt/mnemo2/damian/string/maintenance/transfer/string/string_v10_5/"
derived_dir = "/mnt/mnemo4/damian/STRING_v10_5/STRING_derived_v10_5/transfer/"


def format_channel(input_dir, output_file, channel, protid_prot):
    
    print input_dir
    print output_file
    print channel
    print len(protid_prot)

    fh_out = open(output_file+".inprocess", "w")

    tags = {
         "textmining":  "12",
         "array":       "6",
         "equiv":       "1",
         "experimental":"8",
         "database":    "10",
    }
    
    tag = tags[channel]
    
    if channel in ["textmining", "array", "equiv", "experimental"]:
        
        for report_file in os.listdir(input_dir):
            
            if report_file.startswith("report."):
                
                _open = gzip.open if report_file.endswith(".gz") else open

                header = True
                for line in _open(input_dir+"/"+report_file):

                    if header and line.startswith("#"):
                        continue
                    else:
                        header = False

                    l = line.strip().split("\t")
                    
                    og1, og2, sp, protid1, protid2, undef = l
                    
                    prot1 = protid_prot.get(protid1)
                    prot2 = protid_prot.get(protid2)
                    
                    if prot1 and prot2:
                        print >> fh_out, "\t".join([tag, og1, og2, sp, prot1, prot2])
                    
        
    
    if channel == "database":

        for report_file in os.listdir(input_dir):
            
            if report_file.startswith("report."):
                
                _open = gzip.open if report_file.endswith(".gz") else open

                header = True
                for line in _open(input_dir+"/"+report_file):

                    if header and line.startswith("#"):
                        continue
                    else:
                        header = False

                    l = line.strip().split("\t")
                    
                    og1, og2, sp, protid1, protid2, db = l
                    db = db.split()[-1]
                    
                    prot1 = protid_prot.get(protid1)
                    prot2 = protid_prot.get(protid2)
                    
                    if prot1 and prot2:
                        print >> fh_out, "\t".join([tag, og1, og2, sp, prot1, prot2, db])
        
    fh_out.close()    
    os.system("mv " + output_file+".inprocess " + output_file )


channels = [
    "textmining",
     "array",
     "experimental",
     "equiv",
     "database",
]


protid_prot = {}
for line in open(derived_dir+"protein.shorthands.txt"):
    sp_prot, protid = line.strip().split("\t")
    sp, prot = sp_prot.split(".", 1)
        
    protid_prot[protid] = prot

init_params = []

for channel in channels:
    
    input_dir   = derived_dir + "/gocs_output/" + channel 
    output_dir  = derived_dir + "/transfer_output/" + channel + "_formatted/"
    
    if not os.path.exists(output_dir):
        os.system("mkdir " + output_dir)
    
    
    output_file = output_dir+"report."+channel+".tsv"
    
    if not os.path.exists(output_file):
        init_params.append( (input_dir, output_file, channel, protid_prot) )

processes = {}

for process_num in range(max_processes):
            
    if len(init_params):        
        init_param = init_params.pop(0)
        
        print >> sys.stderr, "Initiating process (initial) %d" % process_num
        processes[process_num] = Process(target=format_channel, args=init_param)
        processes[process_num].start()
        
        sleep(0.1)


if len(init_params):
    while True:
        
        for process_num, process in processes.iteritems():
            if not process.is_alive():
                print >> sys.stderr, "Initiating process in spot %d" % process_num
                init_param = init_params.pop(0)
                processes[process_num] = Process(target=format_channel, args=(init_param))
                processes[process_num].start()
                sleep(0.1)
                
            if len(init_params) == 0: break
        if len(init_params) == 0: break

#
# Wait till processes finish
#

print >> sys.stderr, "Waiting for processes to finish..."

while True:
    still_running = False
    for process_num, process in processes.iteritems():        
        if process.is_alive():
            still_running = True
    
    if not still_running:
        break
    
    sleep(1)

print >> sys.stderr, "Finished executing...."

sys.exit()










