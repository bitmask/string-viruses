from subprocess import Popen
from subprocess import PIPE
import os
import sys
import subprocess
from multiprocessing import Process
from time import sleep

main_folder = "/mnt/mnemo4/damian/STRING_v10_5/STRING_derived_v10_5"
#run_dir    = "/mnt/mnemo2/damian/string/maintenance/transfer/string/string_v10_5/"
run_dir = "/mnt/mnemo2/damian/STRING_v10_5/virus_transfer"

max_processes = 30

levels = set()
#for line in open(main_folder+"/transfer/string_v10.levels_species.tsv"):
for line in open(run_dir+"/transfer/virus.levels_species.tsv"):
    level = line.split("\t")[0]
    levels.add(level)

def run_process(score_name, level):
        
    #stderr_dir = main_folder+"/transfer/stderr/"
    stderr_dir = run_dir+"/transfer/stderr/"


    if score_name == "array":
        beta  = 0.5 
        delta = 0.95 
        gamma = 15 

    if score_name == "experimental":
        beta  = 0.1
        delta = 0.95
        gamma = 15

    if score_name == "actions":
        beta  = 0.1
        delta = 0.95
        gamma = 15
    
    if score_name == "database":
        beta  = 0.1 # databases
        delta = 0.95 # databases
        gamma = 15 # databases

    if score_name == "textmining":
        beta  = 0.2 # textmining
        delta = 0.8 # textmining
        gamma = 15 # textmining

    if score_name == "equiv":
        beta  = 0.8 # equiv_nscore 
        delta = 0.8 # equiv_nscore
        gamma = 15 # equiv_nscore
                    
    #output_file = main_folder+"/transfer/gocs_output/{4}/{0}.gocs_array_out_{1}_{2}_{3}_{4}.tsv".format(level, beta, delta, gamma, score_name)
    output_file = run_dir+"/gocs_output/{4}/{0}.gocs_array_out_{1}_{2}_{3}_{4}.tsv".format(level, beta, delta, gamma, score_name)
    
    if os.path.exists(output_file):
        print "exists...", output_file
        return

    output_file = output_file#+"_run2"

    initL = """python generate_orthogroups_combined_scores_array.py \
--output {5} \
--beta {1} \
--delta {2} \
--gamma {3} \
--ogs_map {6}/transfer/orthogroups_protids/ \
--ogs_list  {6}/transfer/orthogroups_protids/{0}.og_protid.tsv \
--levels_species {6}/transfer/virus.levels_species.tsv \
--tree {6}/transfer/nodes.tree \
--score_name {4} \
--substract_homology False \
--prot_links {6}/transfer/{4}_interact.forvirustrans.tsv \
--sim {6}/transfer/species_species_similarities.tsv""".format(level, beta, delta, gamma, score_name, output_file, run_dir)
    
    #print initL
    print initL
    subprocess.Popen(initL, shell=True).wait()

init_params = []

#score_names = ["array"]
#score_names = ["textmining"]
score_names = ["experimental"]
#score_names = ["database"]
#score_names = ["actions"]
#score_names = ["equiv"] #equiv_nscore
    
for score_name in score_names:
    for level in levels:
        #if "422676" == level:
            init_params.append((score_name, level))

processes = {}

for process_num in range(max_processes):
            
    if len(init_params):        
        init_param = init_params.pop(0)
        
        print >> sys.stderr, "Initiating process (initial) %d" % process_num
        processes[process_num] = Process(target=run_process, args=init_param)
        processes[process_num].start()
        sleep(1)


if len(init_params):
    while True:
        
        for process_num, process in processes.iteritems():
            if not process.is_alive():
                print >> sys.stderr, "Initiating process in spot %d" % process_num
                init_param = init_params.pop(0)
                processes[process_num] = Process(target=run_process, args=(init_param))
                processes[process_num].start()
                sleep(1)
                
            if len(init_params) == 0: break
        if len(init_params) == 0: break

#
# Wait till processes finish
#

print >> sys.stderr, "Waiting for processes to finish..."

while True:
    still_running = False
    for process_num, process in processes.iteritems():        
        if process.is_alive():
            still_running = True
    
    if not still_running:
        break
    
    sleep(1)

print >> sys.stderr, "Finished executing...."


sys.exit()


# 
# 
# 
# 
# 
# 














sys.exit()

# BENCHMARK OGS

#for beta in [0.5]:
#    beta = str(beta)
#    job_str = """python /home/panfs/people/damian/compute_scores9_0/sources/generate_orthogroups_combined_scores.py \\
#    -i     /home/panfs/people/damian/compute_scores9_0/output/ogs_benchmark_9_0.tsv \\
#    -om    /home/panfs/people/damian/compute_scores9_0/output/ \\
#    -out   /home/panfs/people/damian/compute_scores9_0/output/ogs_benchmark_9_0.b%s.results_c1.tsv \\
#    -done  /home/panfs/people/damian/compute_scores9_0/output/ogs_benchmark_9_0.b%s.done3.tsv \\
#    -of    /home/panfs/people/damian/compute_scores9_0/output/og_mapping_benchmark_9_0.tsv \\
#    -tt    /home/panfs/people/damian/compute_scores9_0/output/pruned_ncbi_tree.tsv \\
#    -pl    /home/panfs/people/damian/compute_scores9_0/output/protein_protein_benchmark_links_9_0.tsv \\
#    -c     /home/panfs/people/damian/compute_scores9_0/input/clades/ \\
#    -sp    /home/panfs/people/damian/compute_scores9_0/output/species_per_level.tsv \\
#    -cd    /home/panfs/people/damian/compute_scores8_3/output/connectivity_degree/ogs_connectivity_clades_all/ \\
#    -cf    og_connectivity.tsv \\
#    -h     /home/panfs/people/damian/compute_scores9_0/output/protein_protein_benchmark_homology_9_0.tsv \\
#    -b %s -d 0.0 
#    """ % (beta, beta, beta)
#    job_fh = open("job_gocs.sh", "w")
#    print >> job_fh, job_str
#    job_fh.close()
#    
#    Popen("xmsub -l mem=20gb,walltime=16:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_0/ -e /home/panfs/people/damian/compute_scores9_0/errout/ -o  /home/panfs/people/damian/compute_scores9_0/errout/ -r y job_gocs.sh", shell=True).wait()

    
# RUN ALL    
#
#for i in range(20):
#    for beta in [0.5]:
#        beta = str(beta)
#        i = str(i)
#        job_str = """python /home/panfs/people/damian/compute_scores9_0/sources/generate_orthogroups_combined_scores.py \\
#        -om    /home/panfs/people/damian/compute_scores9_0/output/protid_og_mapping/ \\
#        -of    taxidapp.orthgroups_protid.tsv \\
#        -pm    /home/panfs/people/damian/compute_scores9_0/output/prot_links_div/ \\
#        -pf    protein_protein_links_9_0_gocsInput.tsv \\
#        -i     /home/panfs/people/damian/compute_scores9_0/output/gocs_out_{0}/random.ogs_list.tsv \\
#        -out   /home/panfs/people/damian/compute_scores9_0/output/gocs_out_{0}/ogs_benchmark_9_0.b{1}.results.tsv \\
#        -done  /home/panfs/people/damian/compute_scores9_0/output/gocs_out_{0}/ogs_benchmark_9_0.b{1}.done.tsv \\
#        -tt    /home/panfs/people/damian/compute_scores9_0/output/pruned_ncbi_tree.tsv \\
#        -pl    /home/panfs/people/damian/compute_scores9_0/output/protein_protein_links_9_0_gocsInput.tsv \\
#        -c     /home/panfs/people/damian/compute_scores9_0/input/clades/ \\
#        -sp    /home/panfs/people/damian/compute_scores9_0/output/species_per_level.tsv \\
#        -cd    /home/panfs/people/damian/compute_scores8_3/output/connectivity_degree/ogs_connectivity_clades_all/ \\
#        -cf    og_connectivity.tsv \\
#        -h     /home/panfs/people/damian/compute_scores9_0/output/protein_protein_benchmark_homology_9_0.tsv \\
#        -b {1} -d 0.0 
#        """.format(i, beta)
#        job_fh = open("job_gocs.sh", "w")
#        print >> job_fh, job_str
#        job_fh.close()
#        
#        Popen("xmsub -l mem=120gb,walltime=72:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_0/ -e /home/panfs/people/damian/compute_scores9_0/errout/ -o  /home/panfs/people/damian/compute_scores9_0/errout/ -r y job_gocs.sh", shell=True).wait()
#






# RUN FOR HUMAN BENCHMARK PROTEIN SET


#for beta in [0.5]:
#    beta = str(beta)
#    job_str = """python /home/panfs/people/damian/compute_scores9_0/sources/generate_orthogroups_combined_scores.py \\
#    -om    /home/panfs/people/damian/compute_scores9_0/output/human_benchmark_gocs_out/ \\
#    -of    taxidapp.orthgroups_protid.tsv \\
#    -pm    /home/panfs/people/damian/compute_scores9_0/output/human_benchmark_gocs_out/ \\
#    -pf    protein_protein_links_9_0_gocsInput.tsv \\
#    -i     /home/panfs/people/damian/compute_scores9_0/output/human_benchmark_gocs_out/human_benchmark_ogs_list.tsv \\
#    -out   /home/panfs/people/damian/compute_scores9_0/output/human_benchmark_gocs_out/ogs_benchmark_9_0.b{1}_queue.results.tsv \\
#    -done  /home/panfs/people/damian/compute_scores9_0/output/human_benchmark_gocs_out/ogs_benchmark_9_0.b{1}_queue.done.tsv \\
#    -tt    /home/panfs/people/damian/compute_scores9_0/output/pruned_ncbi_tree.tsv \\
#    -pl    /home/panfs/people/damian/compute_scores9_0/output/protein_protein_links_9_0_gocsInput.tsv \\
#    -c     /home/panfs/people/damian/compute_scores9_0/input/clades/ \\
#    -sp    /home/panfs/people/damian/compute_scores9_0/output/species_per_level.tsv \\
#    -cd    /home/panfs/people/damian/compute_scores8_3/output/connectivity_degree/ogs_connectivity_clades_all/ \\
#    -cf    og_connectivity.tsv \\
#    -h     /home/panfs/people/damian/compute_scores9_0/output/protein_protein_benchmark_homology_9_0.tsv \\
#    -b {1} -d 0.0 
#    """.format(0, beta)
#    job_fh = open("job_gocs.sh", "w")z
#    print >> job_fh, job_str
#    job_fh.close()
#    
#    Popen("xmsub -l mem=20gb,walltime=72:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_0/ -e /home/panfs/people/damian/compute_scores9_0/errout/ -o  /home/panfs/people/damian/compute_scores9_0/errout/ -r y job_gocs.sh", shell=True).wait()
#


# RUN FOR ONE SOCRE


params = [
    # gamma, delta, beta
    (15.0, 1.0,   0.0),
    (15.0, 0.8,   0.0),
    (15.0, 0.6,   0.0),
    (15.0, 0.4,   0.0),
    (15.0, 0.2,   0.0),

    (15.0, 1.0,   0.05),
    (15.0, 0.8,   0.05),
    (15.0, 0.6,   0.05),
    (15.0, 0.4,   0.05),
    (15.0, 0.2,   0.05),

    (15.0, 1.0,   0.1),
    (15.0, 0.8,   0.1),
    (15.0, 0.6,   0.1),
    (15.0, 0.4,   0.1),
    (15.0, 0.2,   0.1),
    
    (9.0, 0.6,   0.1),
    (15.0, 0.6,   0.1),
    (30.0, 0.6,   0.1),

    (9.0, 0.6,   0.1),
    (15.0, 0.6,   0.1),
    (30.0, 0.6,   0.1),

    (9.0, 0.4,   0.1),
    (15.0, 0.4,   0.1),
    (30.0, 0.4,   0.1),


    (9.0, 0.5,   0.6),
    (15.0, 0.5,   0.6),
    (30.0, 0.5,   0.6),


    (15.0, 1,   0.0),
    (15.0, 0.8,   0.05),
    (15.0, 0.9,   0.1),
    (15.0, 0.85,   0.15),
    (15.0, 1,   0.2),
    (15.0, 0.8, 0.2),
    (15.0, 0.6, 0.2),
    (15.0, 0.4, 0.2),
    (15.0, 0.2, 0.2),
    (30.0, 0.6,   0.2),
    (15.0, 0.6,   0.2),
    (9.0, 0.6,   0.2),
    (3.0, 0.6,   0.2),
    (15.0, 0.6,   0.1),
    (15.0, 0.6,   0.2),
    (15.0, 0.6,   0.4),
    (15.0, 0.6,   0.6),
    (15.0, 0.6,   0.8),
    (15.0, 1,   0.5),
    (15.0, 0.8, 0.5),
    (15.0, 0.6, 0.5),
    (15.0, 0.4, 0.5),

]



# load channel

#channels = {}
#for _file in os.listdir("/home/panfs/people/damian/compute_scores9_1/output/protein_links_node_scores/"):
#    channel = _file.split(".", 1)[-1].split("_")[0]
#    channels[channel] = 1

#"".format()
#
#channels = ["neighborhood"]
#channel = "neighborhood"
#
##for channel in channels:
##    for gamma, delta, beta in params:
#
#
#for delta in [0.8]: # slope shift (similarity penalty)
#    for gamma in [15.0]: # slope (similarity penaly)
#        for beta in [0.9]: # paralogs penalty
#            
#            delta = str(delta)
#            beta  = str(beta)
#            gamma = str(gamma)
#            
#            i = 0
#            job_str = """python /home/panfs/people/damian/compute_scores9_1/sources/generate_orthogroups_combined_scores.py \\
#            -om    /home/panfs/people/damian/compute_scores9_0/output/protid_og_mapping/ \\
#            -of    taxidapp.orthgroups_protid.tsv \\
#            -pm    /home/panfs/people/damian/compute_scores9_1/output/protein_links_node_scores/ \\
#            -pf    {4}_prot_prot_scores.tsv.gz \\
#            -i     /home/panfs/people/damian/compute_scores9_0/output/gocs_out_tscore/ogs_root_benchmark_list.tsv \\
#            -out   /home/panfs/people/damian/compute_scores9_1/output/gocs_out_benchmark/gocs_bench_{4}.b{1}.d{2}.g{3}.results.tsv \\
#            -tt    /home/panfs/people/damian/compute_scores9_0/output/pruned_ncbi_tree.tsv \\
#            -c     /home/panfs/people/damian/compute_scores9_0/input/clades/5.clades.txt \\
#            -sp    /home/panfs/people/damian/compute_scores9_0/output/species_per_level.tsv \\
#            -ss    /home/panfs/people/damian/compute_scores9_1/output/species_distances.tsv \\
#            -h     /home/panfs/people/damian/compute_scores9_0/output/protein_protein_benchmark_homology_9_0.tsv \\
#            -b {1} -d {2} -g {3}
#            """.format(i, beta, delta, gamma, channel)
#            job_fh = open("job_gocs.sh", "w")
#            print >> job_fh, job_str
#            job_fh.close()
#            #Popen(job_str, shell=True).wait()
#            #Popen("xmsub -l mem=150gb,walltime=96:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_0/ -e /home/panfs/people/damian/compute_scores9_0/errout/ -o  /home/panfs/people/damian/compute_scores9_0/errout/ -r y job_gocs.sh", shell=True).wait()
#            #Popen("msub -l mem=6gb,walltime=4:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_1/sources/ -e /home/panfs/people/damian/compute_scores9_1/errout/ -o /home/panfs/people/damian/compute_scores9_1/errout/ -r y job_gocs.sh", shell=True).wait()
#


"".format()

### DATABASES AND TEXTMINING_NLP
# The largest channel from database is ECOC

#channels = ["ECOC", "kegg", "database", "textmining_nlp"]
#
#
#for channel in channels:
##for og_set_file in os.listdir("/home/panfs/people/damian/compute_scores9_1/output/og_run_benchmark/"):
#    for og_set_file in ["../1.bechmark_og_set.tsv"]:
#        
#        level_taxid = "1"
#        part = "benchmark"
#        #level_taxid = "1"
#        #part = "benchmark"
#        
#        if level_taxid != "1": continue
#        #if level_taxid == "all": continue
#            
#        for delta in [0.0, 0.1, 0.2, 0.3, 0.5, 0.7, 0.9, 1.0]: # slope shift (similarity penalty)
#            for gamma in [15.0]: # slope (similarity penaly)
#                for beta in [0.0, 0.1, 0.2, 0.3, 0.5, 0.7, 0.9, 1.0]: # paralogs penalty
#    
#                    delta = str(delta)
#                    beta  = str(beta)
#                    gamma = str(gamma)
#                    
#                    i = 0
#                    
#                    out_file = "/home/panfs/people/damian/compute_scores9_1/output/gocs_out_benchmark/{5}.gocs_new_root_{4}.b{1}.d{2}.g{3}.results.tsv.{6}".format(i, beta, delta, gamma, channel, level_taxid, part, og_set_file)
#                    
#                    if os.path.exists(out_file):
#                        continue
#                    
#                    job_str = """python /home/panfs/people/damian/compute_scores9_1/sources/generate_orthogroups_combined_scores.py \\
#                    -om    /home/panfs/people/damian/compute_scores9_1/output/protid_og_mapping_9_1/ \\
#                    -of    taxidapp.orthgroups_protid.tsv \\
#                    -pm    /home/panfs/people/damian/compute_scores9_1/output/protein_links_node_scores/ \\
#                    -pf    {4}_prot_prot_scores.tsv.gz \\
#                    -i     /home/panfs/people/damian/compute_scores9_1/output/og_run_sets_9_1/{6} \\
#                    -out   {7} \\
#                    -tt    /home/panfs/people/damian/compute_scores9_0/output/pruned_ncbi_tree.tsv \\
#                    -c     /home/panfs/people/damian/compute_scores9_0/input/clades/5.clades.txt \\
#                    -sp    /home/panfs/people/damian/compute_scores9_0/output/species_per_level.tsv \\
#                    -ss    /home/panfs/people/damian/compute_scores9_1/output/species_distances.tsv \\
#                    -h     /home/panfs/people/damian/compute_scores9_0/output/protein_protein_benchmark_homology_9_0.tsv \\
#                    -b {1} -d {2} -g {3}
#                    """.format(i, beta, delta, gamma, channel, level_taxid, og_set_file, out_file)
#                    job_fh = open("job_gocs.sh", "w")
#                    print >> job_fh, job_str
#                    job_fh.close()
#                    
#                    #if level_taxid == "1" or level_taxid == "2" or level_taxid == "2759":
#                    Popen("msub -l mem=10gb,walltime=6:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_1/sources/ -e /home/panfs/people/damian/compute_scores9_1/errout/ -o /home/panfs/people/damian/compute_scores9_1/errout/ -r y job_gocs.sh", shell=True).wait()
#                    #else:
#                    #Popen("msub -l mem=20gb,walltime=6:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_1/sources/ -e /home/panfs/people/damian/compute_scores9_1/errout/ -o /home/panfs/people/damian/compute_scores9_1/errout/ -r y job_gocs.sh", shell=True).wait()
#                        
#                    #sys.exit()
#


##### EXPERIMENTAL
#
## experimental   b0.1 d0.8 g15.0
#
#channel = "experimental"
#
#for og_set_file in os.listdir("/home/panfs/people/damian/compute_scores9_1/output/og_run_sets/"):
#    level_taxid = og_set_file.split(".")[0]
#    part = og_set_file.split(".")[-1]
#    
#    #if level_taxid == "1": continue
#    if level_taxid == "all": continue
#        
#    for delta in [0.8]: # slope shift (similarity penalty)
#        for gamma in [15.0]: # slope (similarity penaly)
#            for beta in [0.1]: # paralogs penalty
#                
#                
#                
#                delta = str(delta)
#                beta  = str(beta)
#                gamma = str(gamma)
#                
#                i = 0
#                
#                out_file = "/home/panfs/people/damian/compute_scores9_1/output/gocs_out_full/{5}.gocs_full_{4}.b{1}.d{2}.g{3}.results.tsv.{6}".format(i, beta, delta, gamma, channel, level_taxid, part, og_set_file)
#                if os.path.exists(out_file):
#                    continue
#                
#                job_str = """python /home/panfs/people/damian/compute_scores9_1/sources/generate_orthogroups_combined_scores.py \\
#                -om    /home/panfs/people/damian/compute_scores9_0/output/protid_og_mapping/ \\
#                -of    taxidapp.orthgroups_protid.tsv \\
#                -pm    /home/panfs/people/damian/compute_scores9_1/output/protein_links_node_scores/ \\
#                -pf    {4}_prot_prot_scores.tsv.gz \\
#                -i     /home/panfs/people/damian/compute_scores9_1/output/og_run_sets/{7} \\
#                -out   /home/panfs/people/damian/compute_scores9_1/output/gocs_out_full/{5}.gocs_full_{4}.b{1}.d{2}.g{3}.results.tsv.{6} \\
#                -tt    /home/panfs/people/damian/compute_scores9_0/output/pruned_ncbi_tree.tsv \\
#                -c     /home/panfs/people/damian/compute_scores9_0/input/clades/5.clades.txt \\
#                -sp    /home/panfs/people/damian/compute_scores9_0/output/species_per_level.tsv \\
#                -ss    /home/panfs/people/damian/compute_scores9_1/output/species_distances.tsv \\
#                -h     /home/panfs/people/damian/compute_scores9_0/output/protein_protein_benchmark_homology_9_0.tsv \\
#                -b {1} -d {2} -g {3}
#                """.format(i, beta, delta, gamma, channel, level_taxid, part, og_set_file)
#                job_fh = open("job_gocs.sh", "w")
#                print >> job_fh, job_str
#                job_fh.close()
#                
#                if level_taxid == "1" or level_taxid == "2" or level_taxid == "2759":
#                    Popen("msub -l mem=10gb,walltime=6:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_1/sources/ -e /home/panfs/people/damian/compute_scores9_1/errout/ -o /home/panfs/people/damian/compute_scores9_1/errout/ -r y job_gocs.sh", shell=True).wait()
#                else:
#                    Popen("msub -l mem=4gb,walltime=4:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_1/sources/ -e /home/panfs/people/damian/compute_scores9_1/errout/ -o /home/panfs/people/damian/compute_scores9_1/errout/ -r y job_gocs.sh", shell=True).wait()
#                    
#                #sys.exit()


##### COEXPRESSION
#
## coexpression  b0.3 d0.95 g15.0
#
#
#for og_set_file in os.listdir("/home/panfs/people/damian/compute_scores9_1/output/og_run_sets/"):
#    level_taxid = og_set_file.split(".")[0]
#    part = og_set_file.split(".")[-1]
#    
#    #if level_taxid == "1": continue
#    if level_taxid == "all": continue
#        
#    for delta in [0.95]: # slope shift (similarity penalty)
#        for gamma in [15.0]: # slope (similarity penaly)
#            for beta in [0.3]: # paralogs penalty
#                
#                
#                
#                delta = str(delta)
#                beta  = str(beta)
#                gamma = str(gamma)
#                
#                i = 0
#                
#                out_file = "/home/panfs/people/damian/compute_scores9_1/output/gocs_out_full/{5}.gocs_full_{4}.b{1}.d{2}.g{3}.results.tsv.{6}".format(i, beta, delta, gamma, channel, level_taxid, part, og_set_file)
#                if os.path.exists(out_file):
#                    continue
#                
#                job_str = """python /home/panfs/people/damian/compute_scores9_1/sources/generate_orthogroups_combined_scores.py \\
#                -om    /home/panfs/people/damian/compute_scores9_0/output/protid_og_mapping/ \\
#                -of    taxidapp.orthgroups_protid.tsv \\
#                -pm    /home/panfs/people/damian/compute_scores9_1/output/protein_links_node_scores/ \\
#                -pf    {4}_prot_prot_scores.tsv.gz \\
#                -i     /home/panfs/people/damian/compute_scores9_1/output/og_run_sets/{7} \\
#                -out   /home/panfs/people/damian/compute_scores9_1/output/gocs_out_full/{5}.gocs_full_{4}.b{1}.d{2}.g{3}.results.tsv.{6} \\
#                -tt    /home/panfs/people/damian/compute_scores9_0/output/pruned_ncbi_tree.tsv \\
#                -c     /home/panfs/people/damian/compute_scores9_0/input/clades/5.clades.txt \\
#                -sp    /home/panfs/people/damian/compute_scores9_0/output/species_per_level.tsv \\
#                -ss    /home/panfs/people/damian/compute_scores9_1/output/species_distances.tsv \\
#                -h     /home/panfs/people/damian/compute_scores9_0/output/protein_protein_benchmark_homology_9_0.tsv \\
#                -b {1} -d {2} -g {3}
#                """.format(i, beta, delta, gamma, channel, level_taxid, part, og_set_file)
#                job_fh = open("job_gocs.sh", "w")
#                print >> job_fh, job_str
#                job_fh.close()
#                #Popen(job_str, shell=True).wait()
#                #Popen("xmsub -l mem=150gb,walltime=96:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_0/ -e /home/panfs/people/damian/compute_scores9_0/errout/ -o  /home/panfs/people/damian/compute_scores9_0/errout/ -r y job_gocs.sh", shell=True).wait()
#                if level_taxid == "1" or level_taxid == "2" or level_taxid == "2759":
#                    Popen("msub -l mem=20gb,walltime=6:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_1/sources/ -e /home/panfs/people/damian/compute_scores9_1/errout/ -o /home/panfs/people/damian/compute_scores9_1/errout/ -r y job_gocs.sh", shell=True).wait()
#                else:
#                    Popen("msub -l mem=10gb,walltime=4:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_1/sources/ -e /home/panfs/people/damian/compute_scores9_1/errout/ -o /home/panfs/people/damian/compute_scores9_1/errout/ -r y job_gocs.sh", shell=True).wait()
#
#

sys.exit()

channels = ["neighborhood", "coexpression", "experimental", "RCTM", "BCRT", "NCIN", "ECOC", "kegg", "database", "textmining_nlp"]


action_channels = [
    "BCRT.biochemicalReaction_ll",
    "BCRT.biochemicalReaction_lr",
    "BCRT.biochemicalReaction_rl",
    "BCRT.biochemicalReaction_rr",
    "BCRT.complex",
    "ECOC.biochemicalReaction_ll",
    "ECOC.biochemicalReaction_lr",
    "ECOC.biochemicalReaction_rl",
    "ECOC.biochemicalReaction_rr",
    "ECOC.catalysis_rx",
    "ECOC.catalysis_xr",
    "ECOC.complex",
    "ECOC.modulation_rx_ACTIVATION",
    "ECOC.modulation_rx_ACTIVATION-ALLOSTERIC",
    "ECOC.modulation_rx_INHIBITION",
    "ECOC.modulation_xr_ACTIVATION",
    "ECOC.modulation_xr_ACTIVATION-ALLOSTERIC",
    "ECOC.modulation_xr_INHIBITION",
    "NCIN.biochemicalReaction_ll",
    "NCIN.biochemicalReaction_lr",
    "NCIN.biochemicalReaction_rl",
    "NCIN.biochemicalReaction_rr",
    "NCIN.complex",
    "NCIN.transport_ll",
    "NCIN.transport_lr",
    "NCIN.transport_rl",
    "NCIN.transport_rr",
    "RCTM.biochemicalReaction_ll",
    "RCTM.biochemicalReaction_lr",
    "RCTM.biochemicalReaction_rl",
    "RCTM.biochemicalReaction_rr",
    "RCTM.catalysis_rx_ACTIVATION",
    "RCTM.catalysis_xr_ACTIVATION",
    "RCTM.complex",
    "RCTM.modulation_rx_ACTIVATION",
    "RCTM.modulation_xr_ACTIVATION",
    "database.go_complex",
    "experimental.bind",
    "experimental.complex",
    "experimental.complex_contact",
    "kegg.enzyme_subunit",
    "textmining_nlp.acetyl_rx",
    "textmining_nlp.acetyl_xr",
    "textmining_nlp.act_bind_rx",
    "textmining_nlp.act_bind_xr",
    "textmining_nlp.act_expr_rx",
    "textmining_nlp.act_expr_xr",
    "textmining_nlp.bind",
    "textmining_nlp.complex",
    "textmining_nlp.deacetyl_rx",
    "textmining_nlp.deacetyl_xr",
    "textmining_nlp.demethy_rx",
    "textmining_nlp.demethy_xr",
    "textmining_nlp.dephos_rx",
    "textmining_nlp.dephos_xr",
    "textmining_nlp.glyc_carb_rx",
    "textmining_nlp.glyc_carb_xr",
    "textmining_nlp.glyc_rx",
    "textmining_nlp.glyc_xr",
    "textmining_nlp.methy_rx",
    "textmining_nlp.methy_xr",
    "textmining_nlp.phos_rx",
    "textmining_nlp.phos_xr",
    "textmining_nlp.reg_bind_rx",
    "textmining_nlp.reg_bind_xr",
    "textmining_nlp.reg_expr_rx",
    "textmining_nlp.reg_expr_xr",
    "textmining_nlp.rep_bind_rx",
    "textmining_nlp.rep_bind_xr",
    "textmining_nlp.rep_expr_rx",
    "textmining_nlp.rep_expr_xr",
    "textmining_nlp.ubiq_rx",
    "textmining_nlp.ubiq_xr",
]
#channels = ["BCRT"]
#channels = ["textmining"]

for channel in action_channels:
    
    actions_path = ""
    if channel == "neighborhood":
        delta =  0.8
        gamma = 15.0
        beta  =  0.9

    elif channel == "coexpression":
        delta =  0.95
        gamma = 15.0
        beta  =  0.3

    elif channel == "experimental":
        delta =  0.8
        gamma = 15.0
        beta  =  0.1

    elif channel == "textmining":
        delta =  0.1
        gamma = 15.0
        beta  =  0.1


    elif channel in ["RCTM", "BCRT", "NCIN", "ECOC", "kegg", "database", "textmining_nlp"]:
        beta  = 1.0
        delta = 0.7
        gamma = 15.0
    elif channel in action_channels:
        beta  = 1.0
        delta = 0.7
        gamma = 15.0
        actions_path = "/actions/"
    else:
        sys.exit("Unknown channel")



    for og_set_file in os.listdir("/home/panfs/people/damian/compute_scores9_1/output/og_run_sets_9_1/"):
        level_taxid = og_set_file.split(".")[0]
        part = og_set_file.split(".")[-1]
        if not level_taxid.isdigit(): continue
        
        #if level_taxid != "2302": continue
        
        #if level_taxid != "1": continue
        if level_taxid == "all" or not level_taxid.isdigit(): continue
                                                
        delta = str(delta)
        beta  = str(beta)
        gamma = str(gamma)
        
        i = 0
        
        out_file = "/home/panfs/people/damian/compute_scores9_1/output/gocs_out_full/{8}/{5}.gocs_full_{4}.b{1}.d{2}.g{3}.results.tsv.{6}".format(i, beta, delta, gamma, channel, level_taxid, part, og_set_file, actions_path)
        if os.path.exists(out_file):
            print out_file, "exists!"
            continue
        
        job_str = """python /home/panfs/people/damian/compute_scores9_1/sources/generate_orthogroups_combined_scores.py \\
        -om    /home/panfs/people/damian/compute_scores9_1/output/protid_og_mapping_9_1/ \\
        -of    taxidapp.orthgroups_protid.tsv \\
        -pm    /home/panfs/people/damian/compute_scores9_1/output/protein_links_node_scores/{9} \\
        -pf    {4}_prot_prot_scores.tsv.gz \\
        -i     /home/panfs/people/damian/compute_scores9_1/output/og_run_sets_9_1/{7} \\
        -out   {8} \\
        -tt    /home/panfs/people/damian/compute_scores9_0/output/pruned_ncbi_tree.tsv \\
        -c     /home/panfs/people/damian/compute_scores9_0/input/clades/5.clades.txt \\
        -sp    /home/panfs/people/damian/compute_scores9_0/output/species_per_level.tsv \\
        -ss    /home/panfs/people/damian/compute_scores9_1/output/species_distances.tsv \\
        -h     /home/panfs/people/damian/compute_scores9_0/output/protein_protein_benchmark_homology_9_0.tsv \\
        -b {1} -d {2} -g {3}
        """.format(i, beta, delta, gamma, channel, level_taxid, part, og_set_file, out_file, actions_path)
        job_fh = open("job_gocs.sh", "w")
        print >> job_fh, job_str
        job_fh.close()
        
        #Popen(job_str, shell=True).wait()
        #Popen("xmsub -l mem=150gb,walltime=96:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_0/ -e /home/panfs/people/damian/compute_scores9_0/errout/ -o  /home/panfs/people/damian/compute_scores9_0/errout/ -r y job_gocs.sh", shell=True).wait()
        
        #if level_taxid == "1" or level_taxid == "2" or level_taxid == "2759":
        #    Popen("msub -l mem=25gb,walltime=24:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_1/sources/ -e /home/panfs/people/damian/compute_scores9_1/errout/ -o /home/panfs/people/damian/compute_scores9_1/errout/ -r y job_gocs.sh", shell=True).wait()
        Popen("msub -l mem=6gb,walltime=6:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_1/sources/ -e /home/panfs/people/damian/compute_scores9_1/errout/ -o /home/panfs/people/damian/compute_scores9_1/errout/ -r y job_gocs.sh", shell=True).wait()




#### TEXTMINING

# textmining  b0.1 d0.8 g15.0 # creates long list
# textmining  b0.1 d0.1 g15.0 # 

#channel = "textmining"
#
#for og_set_file in os.listdir("/home/panfs/people/damian/compute_scores9_1/output/og_run_sets/"):
#    level_taxid = og_set_file.split(".")[0]
#    part = og_set_file.split(".")[-1]
#    
#    #if level_taxid == "1": continue
#    if level_taxid == "all": continue
#        
#    for delta in [0.8]: # slope shift (similarity penalty)
#        for gamma in [15.0]: # slope (similarity penaly)
#            for beta in [0.1]: # paralogs penalty
#                
#                
#                
#                delta = str(delta)
#                beta  = str(beta)
#                gamma = str(gamma)
#                
#                i = 0
#                
#                out_file = "/home/panfs/people/damian/compute_scores9_1/output/gocs_out_full/{5}.gocs_full_{4}.b{1}.d{2}.g{3}.results.tsv.{6}".format(i, beta, delta, gamma, channel, level_taxid, part, og_set_file)
#                if os.path.exists(out_file):
#                    continue
#                
#                job_str = """python /home/panfs/people/damian/compute_scores9_1/sources/generate_orthogroups_combined_scores.py \\
#                -om    /home/panfs/people/damian/compute_scores9_0/output/protid_og_mapping/ \\
#                -of    taxidapp.orthgroups_protid.tsv \\
#                -pm    /home/panfs/people/damian/compute_scores9_1/output/protein_links_node_scores/ \\
#                -pf    {4}_prot_prot_scores.tsv.gz \\
#                -i     /home/panfs/people/damian/compute_scores9_1/output/og_run_sets/{7} \\
#                -out   /home/panfs/people/damian/compute_scores9_1/output/gocs_out_full/{5}.gocs_full_{4}.b{1}.d{2}.g{3}.results.tsv.{6} \\
#                -tt    /home/panfs/people/damian/compute_scores9_0/output/pruned_ncbi_tree.tsv \\
#                -c     /home/panfs/people/damian/compute_scores9_0/input/clades/5.clades.txt \\
#                -sp    /home/panfs/people/damian/compute_scores9_0/output/species_per_level.tsv \\
#                -ss    /home/panfs/people/damian/compute_scores9_1/output/species_distances.tsv \\
#                -h     /home/panfs/people/damian/compute_scores9_0/output/protein_protein_benchmark_homology_9_0.tsv \\
#                -b {1} -d {2} -g {3}
#                """.format(i, beta, delta, gamma, channel, level_taxid, part, og_set_file)
#                job_fh = open("job_gocs.sh", "w")
#                print >> job_fh, job_str
#                job_fh.close()
#                
#                if level_taxid == "1" or level_taxid == "2" or level_taxid == "2759":
#                    Popen("msub -l mem=10gb,walltime=6:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_1/sources/ -e /home/panfs/people/damian/compute_scores9_1/errout/ -o /home/panfs/people/damian/compute_scores9_1/errout/ -r y job_gocs.sh", shell=True).wait()
#                else:
#                    Popen("msub -l mem=4gb,walltime=4:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_1/sources/ -e /home/panfs/people/damian/compute_scores9_1/errout/ -o /home/panfs/people/damian/compute_scores9_1/errout/ -r y job_gocs.sh", shell=True).wait()
##                    
#                #sys.exit()


##### TEXTMINING BENCHMARK OLD ROOT LEVEL
#
## coexpression  b0.3 d0.95 g15.0
#
#channel = "textmining"
#for og_set_file in ["../../../compute_scores9_0/output/gocs_out_tscore/ogs_root_benchmark_list.tsv"]:
##for og_set_file in os.listdir("/home/panfs/people/damian/compute_scores9_1/output/og_run_sets/"):
#    
#    level_taxid = "1"
#    part        = "benchmark"
#    
#    #level_taxid = og_set_file.split(".")[0]
#    #part = og_set_file.split(".")[-1]
#    #if level_taxid == "1": continue
#    
#    if level_taxid == "all": continue
#        
#    for delta in [0.1, 0.3, 0.7, 0.9, 1.0]: # slope shift (similarity penalty)
#        for gamma in [15.0]: # slope (similarity penaly)
#            for beta in [0.0, 0.1, 0.3, 0.5, 0.9]: # paralogs penalty
#                
#                delta = str(delta)
#                beta  = str(beta)
#                gamma = str(gamma)
#                
#                i = 0
#                
#                out_file = "/home/panfs/people/damian/compute_scores9_1/output/gocs_out_benchmark/{5}.gocs_full_{4}.b{1}.d{2}.g{3}.results.tsv.{6}".format(i, beta, delta, gamma, channel, level_taxid, part, og_set_file)
#                if os.path.exists(out_file):
#                    continue
#                
#                job_str = """python /home/panfs/people/damian/compute_scores9_1/sources/generate_orthogroups_combined_scores.py \\
#                -om    /home/panfs/people/damian/compute_scores9_0/output/protid_og_mapping/ \\
#                -of    taxidapp.orthgroups_protid.tsv \\
#                -pm    /home/panfs/people/damian/compute_scores9_1/output/protein_links_node_scores/ \\
#                -pf    {4}_prot_prot_scores.tsv.gz \\
#                -i     /home/panfs/people/damian/compute_scores9_1/output/og_run_sets_9_1/{7} \\
#                -out   {8} \\
#                -tt    /home/panfs/people/damian/compute_scores9_0/output/pruned_ncbi_tree.tsv \\
#                -c     /home/panfs/people/damian/compute_scores9_0/input/clades/5.clades.txt \\
#                -sp    /home/panfs/people/damian/compute_scores9_0/output/species_per_level.tsv \\
#                -ss    /home/panfs/people/damian/compute_scores9_1/output/species_distances.tsv \\
#                -h     /home/panfs/people/damian/compute_scores9_0/output/protein_protein_benchmark_homology_9_0.tsv \\
#                -b {1} -d {2} -g {3}
#                """.format(i, beta, delta, gamma, channel, level_taxid, part, og_set_file, out_file)
#                job_fh = open("job_gocs.sh", "w")
#                print >> job_fh, job_str
#                job_fh.close()
#                #Popen(job_str, shell=True).wait()
#                #Popen("xmsub -l mem=150gb,walltime=96:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_0/ -e /home/panfs/people/damian/compute_scores9_0/errout/ -o  /home/panfs/people/damian/compute_scores9_0/errout/ -r y job_gocs.sh", shell=True).wait()
#                if level_taxid == "1" or level_taxid == "2" or level_taxid == "2759":
#                    Popen("msub -l mem=30gb,walltime=24:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_1/sources/ -e /home/panfs/people/damian/compute_scores9_1/errout/ -o /home/panfs/people/damian/compute_scores9_1/errout/ -r y job_gocs.sh", shell=True).wait()
#                else:
#                    Popen("msub -l mem=10gb,walltime=4:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_1/sources/ -e /home/panfs/people/damian/compute_scores9_1/errout/ -o /home/panfs/people/damian/compute_scores9_1/errout/ -r y job_gocs.sh", shell=True).wait()
#                
#

#### TEXTMINING COEXPRESSION NEW ROOT LEVEL

# coexpression  b0.3 d0.95 g15.0
#
#channel = "coexpression"
#for og_set_file in ["../../../compute_scores9_1/output/1.bechmark_og_set.tsv"]:
##for og_set_file in os.listdir("/home/panfs/people/damian/compute_scores9_1/output/og_run_sets/"):
#    
#    level_taxid = "1"
#    part        = "benchmark"
#    
#    #level_taxid = og_set_file.split(".")[0]
#    #part = og_set_file.split(".")[-1]
#    #if level_taxid == "1": continue
#    
#    if level_taxid == "all": continue
#        
#    for delta in [0.1, 0.3, 0.7, 0.9, 1.0]: # slope shift (similarity penalty)
#        for gamma in [15.0]: # slope (similarity penaly)
#            for beta in [0.0, 0.1, 0.3, 0.5, 0.9]: # paralogs penalty
#                
#                delta = str(delta)
#                beta  = str(beta)
#                gamma = str(gamma)
#                
#                i = 0
#                
#                out_file = "/home/panfs/people/damian/compute_scores9_1/output/gocs_out_benchmark/{5}.gocs_newroot_{4}.b{1}.d{2}.g{3}.results.tsv.{6}".format(i, beta, delta, gamma, channel, level_taxid, part, og_set_file)
#                if os.path.exists(out_file):
#                    continue
#                
#                job_str = """python /home/panfs/people/damian/compute_scores9_1/sources/generate_orthogroups_combined_scores.py \\
#                -om    /home/panfs/people/damian/compute_scores9_1/output/protid_og_mapping_9_1/ \\
#                -of    taxidapp.orthgroups_protid.tsv \\
#                -pm    /home/panfs/people/damian/compute_scores9_1/output/protein_links_node_scores/ \\
#                -pf    {4}_prot_prot_scores.tsv.gz \\
#                -i     /home/panfs/people/damian/compute_scores9_1/output/og_run_sets_9_1/{7} \\
#                -out   {8} \\
#                -tt    /home/panfs/people/damian/compute_scores9_0/output/pruned_ncbi_tree.tsv \\
#                -c     /home/panfs/people/damian/compute_scores9_0/input/clades/5.clades.txt \\
#                -sp    /home/panfs/people/damian/compute_scores9_0/output/species_per_level.tsv \\
#                -ss    /home/panfs/people/damian/compute_scores9_1/output/species_distances.tsv \\
#                -h     /home/panfs/people/damian/compute_scores9_0/output/protein_protein_benchmark_homology_9_0.tsv \\
#                -b {1} -d {2} -g {3}
#                """.format(i, beta, delta, gamma, channel, level_taxid, part, og_set_file, out_file)
#                job_fh = open("job_gocs.sh", "w")
#                print >> job_fh, job_str
#                job_fh.close()
#                #Popen(job_str, shell=True).wait()
#                #Popen("xmsub -l mem=150gb,walltime=96:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_0/ -e /home/panfs/people/damian/compute_scores9_0/errout/ -o  /home/panfs/people/damian/compute_scores9_0/errout/ -r y job_gocs.sh", shell=True).wait()
#                if level_taxid == "1" or level_taxid == "2" or level_taxid == "2759":
#                    Popen("msub -l mem=10gb,walltime=24:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_1/sources/ -e /home/panfs/people/damian/compute_scores9_1/errout/ -o /home/panfs/people/damian/compute_scores9_1/errout/ -r y job_gocs.sh", shell=True).wait()
#                else:
#                    Popen("msub -l mem=10gb,walltime=4:00:00 -q cpr -d  /home/panfs/people/damian/compute_scores9_1/sources/ -e /home/panfs/people/damian/compute_scores9_1/errout/ -o /home/panfs/people/damian/compute_scores9_1/errout/ -r y job_gocs.sh", shell=True).wait()
#                
#



