import os
import sys
import gzip
import math

transfer_file = "/g/scb/bork/mering/STRING_derived_v10_5/transfer/transfer_output/4932.transfer_textmining_0.0_0.4.tsv.gz"
direct_file   =  "/g/scb/bork/mering/STRING_derived_v10_5/transfer/full_textmining_score.tsv"
kegg_file = "/g/scb/bork/mering/STRING_derived_v10_5/kegg/kegg_benchmarking.CONN_maps_in.v10.tsv"
shorthands_file = "/g/scb/bork/mering/STRING_derived_v10_5/proteins.shorthands.v10_5.tsv"

input_sp = os.path.basename(transfer_file).split(".")[0]

def pearson(x,y):
    mx = sum(x)/max(len(x), 1)
    my = sum(x)/max(len(x), 1)
    
    cov = 0
    sdx = 0
    sdy = 0
    for i in range(len(x)):
        xi = x[i]
        yi = y[i]
        cov += (xi-mx)*(yi-my)
        sdx += (xi-mx)*(xi-mx)
        sdy += (yi-my)*(yi-my)
        
    sdx = math.sqrt(sdx)
    sdy = math.sqrt(sdy)
    
    if sdx == 0 or sdy == 0:
        return 0
    r = cov/(sdx*sdy)
    
    return r

px = 0.041


def combine_two_scores(score1, score2):
    
    return (1 -
                ( (1-px) * ( # adding px
                    ((1-score1)/(1-px)) * 
                    ((1-score2)/(1-px))
                ) )
            )


def combine_two_scores_with_rho(score1, score2, rho_table):
    
    score1 = 1 - (1-score1)/(1-px) # remove prior
    score2 = 1 - (1-score2)/(1-px)

    comb_score = (1-score1)*(1-score2) # combine scores
    
    comb_score = 1 - (comb_score + rho * math.sqrt(score1*(1-score1) * score2*(1-score2) )  ) # add r +ho
    
    comb_score = 1 - (1-px)*(1-comb_score) # add prior
    
    return comb_score


def print_probabilities(pp_score):
    bin_ratio = 5
    bins = []
    
    for i in range(0, 100, bin_ratio):
        bins.append([])
        
    for pp, score in pp_score.iteritems():
        prot1, prot2 = pp.split("\t")
            
                    
        bin_index = int((((score*100)-0.001)/bin_ratio))
        
        share_kegg = 0
        for kegg in prot_kegg[prot1]:
            if kegg in prot_kegg[prot2]:
                share_kegg = 1
                break
            
        bins[bin_index].append(share_kegg)
    
    
    sum_norm = 0
    for bin_index in range(len(bins)):
        if len(bins[bin_index]) != 0:
            tf_ratio = sum(bins[bin_index])/float(len(bins[bin_index]))
            
            
            print "\t".join([str(bin_index*bin_ratio+float(bin_ratio)/2),
                             str(tf_ratio),
                             str(len(bins[bin_index])),
                             str(len(bins[bin_index])*tf_ratio)])
            sum_norm+=len(bins[bin_index])*tf_ratio
    
    print sum_norm

#
# Load protids
#

prot_protid = {}
protid_prot = {}
for line in open(shorthands_file):
    protid, prot = line.strip().split("\t")
    sp, prot = prot.split(".", 1)
    
    if sp == input_sp:
        
        prot_protid[prot] = protid
        protid_prot[protid] = prot


#
# Load benchmark
#


prot_kegg = {}

for line in open(kegg_file):
    sp, kegg, _, prots = line.strip().split("\t")
    
    if sp == input_sp:
        for prot in prots.split():
            
            prot = prot_protid[prot]
            
            if prot not in prot_kegg:
                prot_kegg[prot] = set()
            prot_kegg[prot].add(kegg)


#
# Load direct score
#

prot_prot_dscore = {}
for line in open(direct_file):
    
    _, prot1, prot2, _, _, score = line.strip().split("\t")
    
    if prot1 < prot2:
        
        if prot1 in prot_kegg and prot2 in prot_kegg:

            prot_prot_dscore[prot1 + "\t" + prot2] = float(score)

#
# Load transfer score
#


prot_prot_tscore = {}
for line in gzip.open(transfer_file):
    
    if line[0] == "#": continue
    
    _, prot1, prot2, _, score = line.strip().split("\t")
    
    if prot1 < prot2:
        
        if prot1 in prot_kegg and prot2 in prot_kegg:
            prot_prot_tscore[prot1 + "\t" + prot2] = float(score)


#
# Calculate rho
#


m1 = []
m2 = []
for pp in prot_prot_dscore:
    
    if pp in prot_prot_tscore:
        
        m1.append(prot_prot_dscore[pp])
        m2.append(prot_prot_tscore[pp])
        
rho = pearson(m1, m2)


#
# COMBINE
#

prot_prot_cscore = {}
prot_prot_rscore = {}
for pp, score in prot_prot_dscore.iteritems():
    
    if pp in prot_prot_tscore:
        cscore = combine_two_scores(score, prot_prot_tscore[pp])
        prot_prot_cscore[pp] = cscore
        
        rscore = combine_two_scores_with_rho(score, prot_prot_tscore[pp], rho)
        prot_prot_rscore[pp] = rscore


#
# PRINT PROBABILITIES
#


for pp_scores in [prot_prot_dscore, prot_prot_tscore, prot_prot_cscore, prot_prot_rscore]:
    print_probabilities(pp_scores)
    print














