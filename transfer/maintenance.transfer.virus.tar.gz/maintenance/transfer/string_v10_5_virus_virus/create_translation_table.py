#!/usr/bin/env python
import os
import sys

orthogroup_folder = "/mnt/mnemo4/damian/STRING_v10_5/STRING_derived_v10_5/transfer/orthogroups_protids/"
output_file = "/mnt/mnemo4/damian/STRING_v10_5/STRING_derived_v10_5/transfer/orthogroup.shorthands.txt"

orthogroups = {}
for file_ in os.listdir(orthogroup_folder):
    
    level = file_.split(".")[0]
    
    for line in open(orthogroup_folder+file_):
        og = line.split()[0]
        orthogroups[og] = level
        

fh = open(output_file, "w")

i = 0
for og in sorted(orthogroups):
    level = orthogroups[og]
    i += 1
    print >> fh, "\t".join([level, og, str(i)])

fh.close()