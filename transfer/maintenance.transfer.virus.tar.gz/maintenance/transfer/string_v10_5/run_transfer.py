from subprocess import Popen
from subprocess import PIPE
import os
import sys
#from rrutils import rropen
max_processes = 20

from multiprocessing import Process
import subprocess

from time import sleep

#run_dir     = "/mnt/mnemo2/damian/string/maintenance/transfer/string/string_v10_5/"
#derived_dir = "/mnt/mnemo4/damian/STRING_v10_5/STRING_derived_v10_5/transfer/"

#run_dir = "/mnt/mnemo2/damian/STRING_v10_5/virus_transfer"
run_dir = "/mnt/mnemo4/helen/virus_transfer"
host_dir = "/mnt/mnemo4/damian/STRING_v10_5/STRING_derived_v10_5" # inputs for cellular organisms
#derived_dir = "/mnt/mnemo2/damian/STRING_v10_5/virus_transfer/transfer"
derived_dir = "/mnt/mnemo4/helen/virus_transfer/transfer"
#script_dir = "/mnt/mnemo2/damian/STRING_v10_5/virus_transfer/maintenance/transfer/string_v10_5"
script_dir = "/mnt/mnemo4/helen/virus_transfer/maintenance/transfer/string_v10_5"


#run_dir     = "/g/bork1/szklarcz/string_maintnance/maintenance/transfer/string/string_v10_5/"
#derived_dir = "/g/bork1/szklarcz/STRING_derived_v10_5/transfer/"

hosts = set()
for line in open(derived_dir + "/host_list"):
    host = line.rstrip("\n")
    hosts.add(host)

levels = set()
all_sps = set()
for line in open(host_dir + "/transfer/string_v10.levels_species.tsv"):
    level = line.split("\t")[0]
    levels.add(level)
    for sp in line.split()[1:]:
        all_sps.add(sp)

def get_blocked_databases(species_to_compute):
    
    blocked_databases = []
    
    for database in os.listdir(host_dir+"/databases_from_cvm_primary"):
    
        for interact_file in os.listdir(host_dir+"/databases_from_cvm_primary/"+database):
            if "_interact." in interact_file:
                sp = interact_file.split(".")[-1]
                if sp == species_to_compute:
                    blocked_databases.append(database)
    if blocked_databases:
        return blocked_databases
    else:
        return ["NA"]


def run_process(channel, blocked, species, alpha, beta, gocs_suffix):
    
    input_taxid   = species
    
    if channel == "actions":
        retain_directionality = "True"
    else:
        retain_directionality = "False"
    
    output_dir = run_dir + "/transfer_output/"+channel
    
    if not os.path.exists(output_dir):
        os.system("mkdir %s" % output_dir)
    
    output_file  = "{0}/{1}.transfer_{2}_{3}_{4}.tsv".format(output_dir, species, channel, alpha, beta)

    if os.path.exists(output_file):
        print "exists...", output_file
        return

    initL = """python {6}/generate_transfer_scores.py \\
    --input    {0} \\
    --alpha    {1} \\
    --beta     {2} \\
    --gocs_folder {5}/gocs_output/{7}/ \\
    --gocs_suffix {4} \\
    --output    {3} \\
    --tree  {10}/transfer/eggNOG_tree.tsv \\
    --hogs_map   {10}/transfer/orthogroups_protids/ \\
    --vogs_map   {5}/transfer/orthogroups_protids/ \\
    --sim  {5}/transfer/host_similarities.tsv \\
    --blocked  {8} \\
    --directional  {9} \\
    """.format(species, alpha, beta, output_file, gocs_suffix, run_dir, script_dir, channel, ",".join(blocked), retain_directionality, host_dir)

    print initL
    
    #job_fh = open("job_transfer.sh", "w")
    #print >> job_fh, initL
    #job_fh.close()
    #print blocked
    #print initL
    subprocess.Popen(initL, shell=True).wait()

################################################################
# FINAL RUN 
################################################################
#
# final textmining: alpha 0.0 
# final textmining: beta  0.4
#
# final neighborhood: alpha 0.0 
# final neighborhood: beta  0.0
#
# final array: alpha 0.0 
# final array: beta  0.0
# Even if we don't penalize much, the final scores fit pretty well to probabilities
#
# substracting the direct child of the level then substracting the score of the target
#
##sps = ["9606"]

init_params = []
#channels = ["textmining_score", "equiv_nscore"]
#channels = ["textmining_score"]
#channels = ["equiv_nscore"]
#channels = ["array_score"]



channels = [
    #"experimental",
    "textmining",
    #"database",
    #"array",
    #"actions",
    #"equiv",
]

for channel in channels:
    
        
    for species in all_sps:
            if species not in hosts: continue
        
            #if species != "511145":
            #    continue
            
            if "database" in channel:
                blocked = get_blocked_databases(species)
            else:
                blocked = ["NA"]
                
            if channel == "equiv":
                alpha = 0.0
                beta  = 0.0
                gocs_suffix = "gocs_array_out_0.8_0.8_15_equiv.tsv"
            if channel == "textmining":
                #alpha = 0.05
                #beta  = 0.05
                alpha = 0.0
                beta  = 0.4
                gocs_suffix = "gocs_array_out_0.2_0.8_15_textmining.tsv"
            if channel == "array":
                alpha = 0.0
                beta  = 0.0
                gocs_suffix = "gocs_array_out_0.5_0.95_15_array.tsv"
            if "database" in channel:
                alpha = 0.0
                beta  = 0.1
                gocs_suffix = "gocs_array_out_0.1_0.95_15_%s.tsv" % channel
            if channel == "textmining_nlp_score":
                alpha = 0.0
                beta  = 0.1
                gocs_suffix = "gocs_array_out_0.1_0.95_15_%s.tsv" % channel
            if channel == "experimental":
                alpha = 0.05
                beta  = 0.05
                gocs_suffix = "gocs_array_out_0.1_0.95_15_%s.tsv" % channel
            if "actions" in channel:
                alpha = 0.1
                beta  = 0.1
                gocs_suffix = "gocs_array_out_0.1_0.95_15_%s.tsv" % channel


            init_params.append((channel, blocked, species, alpha, beta, gocs_suffix))


processes = {}

for process_num in range(max_processes):
            
    if len(init_params):        
        init_param = init_params.pop(0)
        
        print >> sys.stderr, "Initiating process (initial) %d" % process_num
        processes[process_num] = Process(target=run_process, args=init_param)
        processes[process_num].start()
        
        sleep(0.1)


if len(init_params):
    while True:
        
        for process_num, process in processes.iteritems():
            if not process.is_alive():
                print >> sys.stderr, "Initiating process in spot %d" % process_num
                init_param = init_params.pop(0)
                processes[process_num] = Process(target=run_process, args=(init_param))
                processes[process_num].start()
                sleep(0.1)
                
            if len(init_params) == 0: break
        if len(init_params) == 0: break

#
# Wait till processes finish
#

print >> sys.stderr, "Waiting for processes to finish..."

while True:
    still_running = False
    for process_num, process in processes.iteritems():        
        if process.is_alive():
            still_running = True
    
    if not still_running:
        break
    
    sleep(1)

print >> sys.stderr, "Finished executing...."

sys.exit()










